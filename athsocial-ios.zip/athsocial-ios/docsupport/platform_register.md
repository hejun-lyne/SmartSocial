
## Google 
从 [Google 官方文档](https://developers.google.com/identity/sign-in/ios/start-integrating) 的 **Get an OAuth client ID** 小节开始看起，首先要创建一个支持谷歌登录的 Google API 服务：

<img src='google_create_client.png' width = 500/>


成功后，会拿到一个 `clientID`，该 ID 就是需要传给 Service 的 id：

<img src='google_client_id.png' width = 500/>

然后，需要在工程的 URLTypes 中，加入 **reverse** `clientID`，即将 `1234-abcd.apps.googleusercontent.com` 写成 `com.googleusercontent.apps.1234-abcd`。

<img src='google_url_type.png' width = 750/>

随后，注册谷歌 platform，让 service 内部进行必要的初始化。
```objc
NSMutableDictionary *config = [NSMutableDictionary new];
[config athsocial_setupGoogleClientId:kGoogleClientId];

[ATH_SERVICE(IATHSocial) registerSocialPlatforms:ATHSocialPlatformGoogle
                                withConfiguration:config];
```

> 在需要使用多个三方平台时，推荐用同一个 config 设置所有参数，随后用位或传入多个平台：`[ATH_SERVICE(IATHSocial) registerSocialPlatforms:ATHSocialPlatformGoogle|ATHSocialPlatformFacebook|... withConfiguration:config];`

## Facebook

进入 [官方网站](https://developers.facebook.com/docs/facebook-login/ios)，从 `3.在 Facebook 注册和配置您的应用` 开始进行。设置完 `info.plist` 后即可，后续步骤均已在 Service 内部实现。

随后，注册 FB platform，让 service 内部进行必要的初始化。

```objc
//Facebook SDK 自动读取 plist，因此无需设置任何 config
[ATH_SERVICE(IATHSocial) registerSocialPlatforms:ATHSocialPlatformFacebook
                                withConfiguration:config];
```


> Facebook 有较 [严格的资料管理](https://developers.facebook.com/docs/facebook-login/review/what-is-login-review)，目前暂时写死了读取权限的 `public_profile` 以及发布权限的 `publish_pages`，`manage_pages`（这两项需要 FB 审核，需要知会产品/市场）。


## Twitter

注册推特开发者账号，然后 [创建一个应用](https://apps.twitter.com/)，并且 **一定填好一个 callbackUrl**，该 url 可以不对应任何实际页面，但需要与后续传给 Service 的一致。

为 App 设置安全域名：api.twitter.com，随后用正确的参数初始化 Service：
```objc
[config athsocial_setupTwitterConsumerKey:YOUR_CONSUMER_KEY
consumerSecret:YOUR_CONSUMER_SECRET 
redirectUrl:YOUR_REDIRECT_URL];

[ATH_SERVICE(IATHSocial) registerSocialPlatforms:ATHSocialPlatformTwitter
                                withConfiguration:config];
```

> 需要注意，此处传入的 `redirectUrl` 务必要和 Twitter 后台设置的 `callbackUrl` 一致。


## Instagram

在 [官方网站](https://www.instagram.com/developer/) 注册开发者帐号，并在 plist scheme 中加入 instagram 用于允许跳转，同样此处会被要求填入一个 redirect URI，需要确保传给 Service 的和这里填写的一致，同时，测试阶段需要开启 implicit OAuth，确保可以正常授权。

为 App 设置安全域名：api.instagram.com，随后用正确的参数初始化 Service：
```objc
NSMutableDictionary *config = [NSMutableDictionary new];
[config athsocial_setupInstagramClientId:YOUR_CLIENT_ID redirectUrl:REDIRECT_URL];

[ATH_SERVICE(IATHSocial) registerSocialPlatforms:ATHSocialPlatformInstagram
                                withConfiguration:config];
```
> 需要注意，此处的 uri 必须和 instagram 后台 Security 栏的 Valid redirect URIs 一致。

> Instagram 对于用户授权操作也有严格的审核，app 上架之前，需要在 Instagram 后台把对应 app 提交审核。

由于 Instagram 的分享功能不走任何 web 流程，是直接的文件分享，因此本质是不需要授权的过程，所以未授权依然可以分享。

## VK

在 [官方网站](https://vk.com/dev) 注册开发者帐号，并创建 App、配置好 BundleID。随后，需要在 plist scheme 中配置 vkauthorize。
随后，用正确的参数初始化 Service：
```objc
NSMutableDictionary *config = [NSMutableDictionary new];
[config athsocial_setupVKAppId:YOUR_APPLICATION_ID];

[ATH_SERVICE(IATHSocial) registerSocialPlatforms:ATHSocialPlatformVK
                                withConfiguration:config];
```

