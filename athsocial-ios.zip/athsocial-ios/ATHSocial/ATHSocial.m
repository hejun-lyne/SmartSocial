//
//  ATHSocial.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#define SUPPOERT_WECHAT 0

#import "ATHSocial.h"
#import "NSDictionary+SocialParameters.h"
#import "ATHSocialDefines.h"

#if SUPPORT_WECHAT
#import "WXApi.h"
#import "ATHSocialWechatImpl.h"
#endif
#import "ATHSocialBaseImpl.h"
//#import "ATHSocialWeiboImpl.h"
//#import "ATHSocialGoogleImpl.h"
//#import "ATHSocialFacebookImpl.h"
//#import "ATHSocialTwitterImpl.h"

NSString * const kTokenSecretKey = @"tokenSecret";
NSString * const kUserIdKey = @"uid";

ATH_INSTANCE_SERVICE_EXPORT(IATHSocial, ATHSocial, sharedInstance)

@interface ATHSocial ()
#if SUPPORT_WECHAT
@property (nonatomic, strong) ATHSocialWechatImpl *wechatImpl;
#endif
@property (nonatomic, strong) NSDictionary <NSNumber *, ATHSocialBaseImpl *> *platformImplMap;

@property (nonatomic, assign) ATHShareChannel lastOpenedChannel;
@property (nonatomic, assign) ATHSocialPlatform lastOpenedPlatform;
@property (nonatomic, strong) NSDictionary *platformConfig;

@property (nonatomic, weak) UIApplication *application;
@property (nonatomic, strong) NSDictionary *launchOptions;

@end

@implementation ATHSocial

@synthesize uiDelegate = _uiDelegate;
@synthesize loggerDelegate = _loggerDelegate;
@synthesize webImageDelegate = _webImageDelegate;

ATH_SINGLETON_IMPLEMENTATION

- (void)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.application = application;
    self.launchOptions = [launchOptions copy];
}

- (void)registerSocialPlatforms:(ATHSocialPlatform)platforms withConfiguration:(NSDictionary *)platformConfig{
    NSMutableDictionary *implMap = [NSMutableDictionary new];
    self.platformConfig = [platformConfig copy];
    
    __weak typeof(self) wself = self;
    ATHSocialImplViewControllerGenerator generator = ^UIViewController *{
        return [wself.uiDelegate viewControllerForPresent];
    };
    if (platforms & ATHSocialPlatformSinaWeibo) {
        if ([self _platformAlreadyRegistered:ATHSocialPlatformSinaWeibo]) {
            [LOGGER log:@"!!!!!!!!ATHSocial registering platform [ATHSocialPlatformSinaWeibo] more than once!!!!!!!!!"];
        } else {
            Class weiboImplClass = NSClassFromString(@"ATHSocialWeiboImpl");
            NSAssert(weiboImplClass != nil, @"Weibo not available, plz check your pod!");
            if (weiboImplClass) {
                ATHSocialBaseImpl *weiboImpl = [weiboImplClass new];
                [weiboImpl config:@{
                                    @"appKey": [self.platformConfig athsocial_weiboAppKey],
                                    @"appSecret": [self.platformConfig athsocial_weiboSecret],
                                    @"redirectUrl": [self.platformConfig athsocial_weiboRedirectUrl],
                                    @"ssoOnly": @([self.platformConfig athsocial_weiboAuthPolicy] == ATHAuthPolicySSOOnly)
                                    }];
                [implMap setObject:weiboImpl forKey:@(ATHSocialPlatformSinaWeibo)];
            }
        }
    }
    if (platforms & ATHSocialPlatformWechat) {
#if SUPPORT_WECHAT
        NSString *appid = [self.platformConfig athsocial_wechatAppid];
        [WXApi registerApp:appid];
        self.wechatImpl = [ATHSocialWechatImpl new];
        [impls addObject:self.wechatImpl];
#else
        [LOGGER log:@"Wechat not supported yet"];
        NSAssert(NO, @"Wechat is not supported yet, plz dont use it.");
#endif
    }
    if (platforms & ATHSocialPlatformQQ) {
        
    }
    if (platforms & ATHSocialPlatformGoogle) {
        if ([self _platformAlreadyRegistered:ATHSocialPlatformGoogle]) {
            [LOGGER log:@"!!!!!!!!ATHSocial registering platform [ATHSocialPlatformGoogle] more than once!!!!!!!!!"];
        }else {
            Class googleImplClass = NSClassFromString(@"ATHSocialGoogleImpl");
            NSAssert(googleImplClass != nil, @"Google not available, plz check your pod!");
            if (googleImplClass) {
                ATHSocialBaseImpl *googleImpl = [googleImplClass new];
                [googleImpl config:@{
                                     @"clientId": [self.platformConfig athsocial_googleClientId],
                                     @"viewControllerGenerator": generator
                                     }];
                [implMap setObject:googleImpl forKey:@(ATHSocialPlatformGoogle)];
            }
        }
        
    }
    if (platforms & ATHSocialPlatformFacebook) {
        if ([self _platformAlreadyRegistered:ATHSocialPlatformFacebook]) {
            [LOGGER log:@"!!!!!!!!ATHSocial registering platform [ATHSocialPlatformFacebook] more than once!!!!!!!!!"];
            return ;
        }else {
            Class facebookImplClass = NSClassFromString(@"ATHSocialFacebookImpl");
            NSAssert(facebookImplClass != nil, @"Facebook not available, plz check your pod!");
            if (facebookImplClass) {
                ATHSocialBaseImpl *facebookImpl = [facebookImplClass new];
                [facebookImpl config:@{
                                       @"application": self.application ? : [UIApplication sharedApplication],
                                       @"launchOptions": self.launchOptions ? : @{},
                                       @"viewControllerGenerator": generator
                                       }];
                [implMap setObject:facebookImpl forKey:@(ATHSocialPlatformFacebook)];
            }
        }
        
    }
    if (platforms & ATHSocialPlatformTwitter) {
        if ([self _platformAlreadyRegistered:ATHSocialPlatformTwitter]) {
            [LOGGER log:@"!!!!!!!!ATHSocial registering platform [ATHSocialPlatformTwitter] more than once!!!!!!!!!"];
            return ;
        }else {
            Class twitterImplClass = NSClassFromString(@"ATHSocialTwitterImpl");
            NSAssert(twitterImplClass != nil, @"Twitter not available, plz check your pod!");
            if (twitterImplClass) {
                ATHSocialBaseImpl *twitterImpl = [twitterImplClass new];
                [twitterImpl config:@{
                                      @"consumerKey": [self.platformConfig athsocial_twitterConsumerKey],
                                      @"consumerSecret": [self.platformConfig athsocial_twitterConsumerSecret],
                                      @"redirectUrl": [self.platformConfig athsocial_twitterRedirectUrl],
                                      @"viewControllerGenerator": generator
                                      }];
                [implMap setObject:twitterImpl forKey:@(ATHSocialPlatformTwitter)];
            }
        }
        
    }
    if (platforms & ATHSocialPlatformInstagram) {
        if ([self _platformAlreadyRegistered:ATHSocialPlatformInstagram]) {
            [LOGGER log:@"!!!!!!!!ATHSocial registering platform [ATHSocialPlatformInstagram] more than once!!!!!!!!!"];
            return ;
        }else {
            Class insImplClass = NSClassFromString(@"ATHSocialInstagramImpl");
            NSAssert(insImplClass != nil, @"Instagram not available, plz check your pod");
            if (insImplClass) {
                ATHSocialBaseImpl *insImpl = [insImplClass new];
                [insImpl config:@{
                                  @"clientId": [self.platformConfig athsocial_instagramClientId],
                                  @"redirectUrl": [self.platformConfig athsocial_instagramRedirectUrl],
                                  @"viewControllerGenerator": generator
                                  }];
                [implMap setObject:insImpl forKey:@(ATHSocialPlatformInstagram)];
            }
        }
        
    }
    if (platforms & ATHSocialPlatformVK) {
        if ([self _platformAlreadyRegistered:ATHSocialPlatformVK]) {
            [LOGGER log:@"!!!!!!!!ATHSocial registering platform [ATHSocialPlatformVK] more than once!!!!!!!!!"];
            return ;
        }else {
            Class vkImplClass = NSClassFromString(@"ATHSocialVKImpl");
            NSAssert(vkImplClass != nil, @"VK not available, plz check your pod.");
            if (vkImplClass) {
                ATHSocialBaseImpl *vkImpl = [vkImplClass new];
                [vkImpl config:@{
                                 @"appId": [self.platformConfig athsocial_VKAppId],
                                 @"viewControllerGenerator": generator
                                 }];
                [implMap setObject:vkImpl forKey:@(ATHSocialPlatformVK)];
            }
        }
    }
    
    
    if (platforms & ATHSocialPlatformTwitch) {
        if ([self _platformAlreadyRegistered:ATHSocialPlatformTwitch]) {
            [LOGGER log:@"!!!!!!!!ATHSocial registering platform [ATHSocialPlatformTwitch] more than once!!!!!!!!!"];
            return ;
        }else {
            Class twitchImplClass = NSClassFromString(@"ATHSocialTwitchImpl");
            NSAssert(twitchImplClass != nil, @"VK not available, plz check your pod.");
            if (twitchImplClass) {
                ATHSocialBaseImpl *twitchImpl = [twitchImplClass new];
                [twitchImpl config:@{
                                     @"clientId": [self.platformConfig athsocial_twitchClientId],
                                     @"redirectUrl": [self.platformConfig athsocial_twitchRedirectUrl],
                                     @"secret": [self.platformConfig athsocial_twitchSecret],
                                     @"viewControllerGenerator": generator
                                     }];
                [implMap setObject:twitchImpl forKey:@(ATHSocialPlatformTwitch)];
            }
        }
    }

    if (self.platformImplMap) {
//        If both dictionaries contain the same key, the receiving dictionary’s previous value object for that key is sent a release message, and the new value object takes its place.
        [implMap addEntriesFromDictionary:self.platformImplMap];
    }
    self.platformImplMap = [implMap copy];
    
    [LOGGER log:@"Activate 3rd platform complete: %lx",(long)platforms];
}


- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation
{
    
    ATHSocialBaseImpl *impl = [self _implToHandleOpenURL];
    
    self.lastOpenedChannel = ATHShareChannelInvalid;
    self.lastOpenedPlatform = ATHSocialPlatformInvalid;
    
    return [impl application:application
               handleOpenURL:url
           sourceApplication:sourceApp
                  annotation:annotation];
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    
    ATHSocialBaseImpl *impl = [self _implToHandleOpenURL];
    
    self.lastOpenedChannel = ATHShareChannelInvalid;
    self.lastOpenedPlatform = ATHSocialPlatformInvalid;
    
    return [impl application:app
                     openURL:url
                     options:options];
}

- (void)shareToChannel:(ATHShareChannel)channel info:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    if (channel == ATHShareChannelInvalid) {
        completion(NO, [self _athshareErrorWithReason:@"Invalid share channel."]);
        return ;
    }
    
    ATHSocialBaseImpl *impl = [self _implForPlatform:[self _convertChannelToPlatform:channel]];
    [impl shareWithInfo:info completion:completion];
    
    self.lastOpenedChannel = channel;
    self.lastOpenedPlatform = ATHSocialPlatformInvalid;
}

- (void)requestAuthForPlatform:(ATHSocialPlatform)platform extendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError *))authCompletion
{
    if (platform == ATHShareChannelInvalid) {
        authCompletion(nil, [self _athshareErrorWithReason:@"Invalid auth platform."]);
        return ;
    }
    ATHSocialBaseImpl *impl = [self _implForPlatform:platform];
    [impl requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion];
    
    self.lastOpenedChannel = ATHShareChannelInvalid;
    self.lastOpenedPlatform = platform;
    
    [LOGGER log:@"Requesting auth for: %li",platform];
}

- (void)requestUserInfoForPlatform:(ATHSocialPlatform)platform completion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    if (platform == ATHShareChannelInvalid) {
        userInfoCompletion(nil, [self _athshareErrorWithReason:@"Invalid user info platform."]);
        return ;
    }
    ATHSocialBaseImpl *impl = [self _implForPlatform:platform];
    [impl requestUserInfoWithCompletion:userInfoCompletion];
    
    self.lastOpenedChannel = ATHShareChannelInvalid;
    self.lastOpenedPlatform = platform;
    
    [LOGGER log:@"Requesting userInfo for: %li",platform];
}

- (void)cleanAuthCacheForPlatforms:(ATHSocialPlatform)platforms
{
    for (ATHSocialBaseImpl *impl in self.platformImplMap.allValues) {
        [impl onLogoutAndRemoveAllTokens:platforms];
    }
}

#pragma mark - Helpers

- (ATHSocialBaseImpl *)_implToHandleOpenURL
{
    ATHSocialPlatform platform = self.lastOpenedPlatform;
    if (platform == ATHSocialPlatformInvalid) {
        platform = [self _convertChannelToPlatform:self.lastOpenedChannel];
    }
    return [self _implForPlatform:platform];
}


- (ATHSocialBaseImpl *)_implForPlatform:(ATHSocialPlatform)platform
{
    return self.platformImplMap[@(platform)];
}

- (NSError *)_athshareErrorWithReason:(NSString *)reason
{
    return [NSError errorWithDomain:@"ATHSocialError"
                               code:-1
                           userInfo:@{@"reason":reason?:@"Unknown error."}];
}

- (ATHSocialPlatform)_convertChannelToPlatform:(ATHShareChannel)channel{
    switch (channel) {
        case ATHShareChannelInvalid:
            return ATHSocialPlatformInvalid;
        case ATHShareChannelSinaWeibo:
            return ATHSocialPlatformSinaWeibo;
        case ATHShareChannelWechatMoments:
        case ATHShareChannelWechatFriend:
            return ATHSocialPlatformWechat;
        case ATHShareChannelFacebook:
            return ATHSocialPlatformFacebook;
        case ATHShareChannelTwitter:
            return ATHSocialPlatformTwitter;
        case ATHShareChannelInstagram:
            return ATHSocialPlatformInstagram;
        case ATHShareChannelVK:
            return ATHSocialPlatformVK;
        default:
            return ATHSocialPlatformInvalid;
    }
}

- (BOOL)_platformAlreadyRegistered:(ATHSocialPlatform)platform
{
    return [self.platformImplMap objectForKey:@(platform)] != nil;
}

@end

