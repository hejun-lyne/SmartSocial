//
//  NSMutableDictionary+SocialParameters.m
//  ATHContext
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018年 YY. All rights reserved.
//

#import "NSDictionary+SocialParameters.h"

#define GET_KEY(key) @"athsocial_"#key""


@implementation NSMutableDictionary (ATHSetSocialParameters)

#pragma mark - Setters
- (void)athsocial_setupWechatAppId:(NSString *)wechatAppid
{
    [self setObject:wechatAppid forKey:GET_KEY(wechatAppId)];
}
- (void)athsocial_setupWeiboAppKey:(NSString *)weiboAppKey secret:(NSString *)secret redirectUrl:(NSString *)redirectUrl authPolicy:(ATHAuthPolicy)authPolicy
{
    [self setObject:secret forKey:GET_KEY(weiboSecret)];
    [self setObject:weiboAppKey forKey:GET_KEY(weiboAppKey)];
    [self setObject:redirectUrl forKey:GET_KEY(weiboRedirectUrl)];
    [self setObject:@(authPolicy) forKey:GET_KEY(weiboAuthPolicy)];
}

- (void)athsocial_setupGoogleClientId:(NSString *)googleClientId
{
    [self setObject:googleClientId forKey:GET_KEY(googleClientId)];
}

- (void)athsocial_setupTwitterConsumerKey:(NSString *)consumerKey consumerSecret:(NSString *)consumerSecret redirectUrl:(NSString *)url
{
    [self setObject:consumerKey forKey:GET_KEY(twitterConsumerKey)];
    [self setObject:consumerSecret forKey:GET_KEY(twitterConsumerSecret)];
    [self setObject:url forKey:GET_KEY(twitterRedirectUrl)];
}

- (void)athsocial_setupInstagramClientId:(NSString *)clientId redirectUrl:(NSString *)url
{
    [self setObject:clientId forKey:GET_KEY(instagramClientId)];
    [self setObject:url forKey:GET_KEY(instagramRedirectUrl)];
}

- (void)athsocial_setupVKAppId:(NSString *)appId
{
    [self setObject:appId forKey:GET_KEY(VKAppId)];
}

- (void)athsocial_setupTwitchClientId:(NSString *)clientId secret:(NSString *)secret redirectUrl:(NSString *)redirectUrl
{
    [self setObject:clientId forKey:GET_KEY(twitchClientId)];
    [self setObject:secret forKey:GET_KEY(twitchSecret)];
    [self setObject:redirectUrl forKey:GET_KEY(twitchRedirectUrl)];
}

@end


#define IMP_GET_OBJECT_VALUE(type, key) \
- (type *)athsocial_##key \
{\
return [self objectForKey:GET_KEY(key)];\
}

#define IMP_GET_SIMPLE_VALUE(type, key, transform) \
- (type)athsocial_##key \
{\
return [[self objectForKey:GET_KEY(key)] transform];\
}

@implementation NSDictionary (ATHGetSocialParameters)
#pragma mark - Getters

IMP_GET_OBJECT_VALUE(NSString, wechatAppId)

IMP_GET_OBJECT_VALUE(NSString, weiboAppKey)
IMP_GET_OBJECT_VALUE(NSString, weiboRedirectUrl)
IMP_GET_OBJECT_VALUE(NSString, weiboSecret)
IMP_GET_SIMPLE_VALUE(ATHAuthPolicy, weiboAuthPolicy, integerValue)

IMP_GET_OBJECT_VALUE(NSString, googleClientId)

IMP_GET_OBJECT_VALUE(NSString, twitterConsumerKey)
IMP_GET_OBJECT_VALUE(NSString, twitterConsumerSecret)
IMP_GET_OBJECT_VALUE(NSString, twitterRedirectUrl)

IMP_GET_OBJECT_VALUE(NSString, instagramClientId)
IMP_GET_OBJECT_VALUE(NSString, instagramRedirectUrl)

IMP_GET_OBJECT_VALUE(NSString, VKAppId)


IMP_GET_OBJECT_VALUE(NSString, twitchClientId)
IMP_GET_OBJECT_VALUE(NSString, twitchRedirectUrl)
IMP_GET_OBJECT_VALUE(NSString, twitchSecret)
@end
