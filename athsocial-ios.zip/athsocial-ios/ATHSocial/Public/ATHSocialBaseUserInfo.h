//
//  ATHSocialBaseUserInfo.h
//  ATHContext
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018 YY. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, ATHSocialUserGender){
    ATHSocialUserGenderUnknown = 0,
    ATHSocialUserGenderMale    = 1,
    ATHSocialUserGenderFemale  = 2,
};

/**
 三方平台用户信息，由于平台差异性，下面的字段并不保证全部都可以获取的到，但对于绝大多数三方平台，昵称头像 uid 都是可以获取到的。
 */
@interface ATHSocialBaseUserInfo : NSObject

//用户昵称
@property (nonatomic, strong) NSString *nickname;
//用户在三方平台上的 uid
@property (nonatomic, strong) NSString *uid;
//用户在三方平台的头像
@property (nonatomic, strong) NSString *avatarUrl;
//用户在三方平台的性别信息
@property (nonatomic, assign) ATHSocialUserGender gender;
//用户在三方平台的个性签名
@property (nonatomic, strong) NSString *signature;

@end

NS_ASSUME_NONNULL_END
