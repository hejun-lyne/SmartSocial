//
//  NSMutableDictionary+SocialParameters.h
//  ATHContext
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018年 YY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ATHSocialDefines.h"

@interface NSMutableDictionary (ATHSetSocialParameters)

#pragma mark - Setters
- (void)athsocial_setupWechatAppId:(NSString *)wechatAppid;

- (void)athsocial_setupWeiboAppKey:(NSString *)weiboAppKey secret:(NSString *)secret redirectUrl:(NSString *)redirectUrl authPolicy:(ATHAuthPolicy)authPolicy;

- (void)athsocial_setupGoogleClientId:(NSString *)googleClientId;

- (void)athsocial_setupTwitterConsumerKey:(NSString *)consumerKey consumerSecret:(NSString *)consumerSecret redirectUrl:(NSString *)url;

- (void)athsocial_setupInstagramClientId:(NSString *)clientId redirectUrl:(NSString *)url;

- (void)athsocial_setupVKAppId:(NSString *)appId;

- (void)athsocial_setupTwitchClientId:(NSString *)clientId secret:(NSString *)secret redirectUrl:(NSString *)redirectUrl;
@end


@interface NSDictionary (ATHGetSocialParameters)
#pragma mark - Getters
- (NSString *)athsocial_wechatAppId;

- (NSString *)athsocial_weiboAppKey;
- (NSString *)athsocial_weiboSecret;
- (NSString *)athsocial_weiboRedirectUrl;
- (ATHAuthPolicy)athsocial_weiboAuthPolicy;

- (NSString *)athsocial_googleClientId;

- (NSString *)athsocial_twitterConsumerKey;
- (NSString *)athsocial_twitterConsumerSecret;
- (NSString *)athsocial_twitterRedirectUrl;

- (NSString *)athsocial_instagramClientId;
- (NSString *)athsocial_instagramRedirectUrl;

- (NSString *)athsocial_VKAppId;

- (NSString *)athsocial_twitchClientId;
- (NSString *)athsocial_twitchRedirectUrl;
- (NSString *)athsocial_twitchSecret;

@end
