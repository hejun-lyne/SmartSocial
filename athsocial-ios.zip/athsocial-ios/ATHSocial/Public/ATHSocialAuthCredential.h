//
//  ATHSocialAuthCredential.h
//  ATHContext
//
//  Created by Gocy on 2018/6/7.
//  Copyright © 2018 YY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ATHSocialDefines.h"

//NS_ASSUME_NONNULL_BEGIN

@interface ATHSocialAuthCredential : NSObject
//三方平台的 accessToken，用于和服务器通讯
@property (nonatomic, strong) NSString *token;
//token 的预计过期时间，service 内部应自带管理，但业务层也可根据该时间自己决定是否重新进行授权流程
@property (nonatomic, strong) NSDate *estimatedExpireDate;
//三方平台标识
@property (nonatomic, assign) ATHSocialPlatform platform;
//一些自定义信息（如有）
@property (nonatomic, strong) NSDictionary *customInfo;

@end

//NS_ASSUME_NONNULL_END
