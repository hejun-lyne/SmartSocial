//
//  ATHSocialAuthCredential.m
//  ATHContext
//
//  Created by Gocy on 2018/6/7.
//  Copyright © 2018 YY. All rights reserved.
//

#import "ATHSocialAuthCredential.h"

@interface ATHSocialAuthCredential () <NSCopying,NSCoding>

@end

@implementation ATHSocialAuthCredential

- (id)copyWithZone:(NSZone *)zone
{
    ATHSocialAuthCredential *cred = [ATHSocialAuthCredential new];
    cred.token = [self.token copyWithZone:zone];
    cred.estimatedExpireDate = [self.estimatedExpireDate copyWithZone:zone];
    cred.platform = self.platform;
    cred.customInfo = [self.customInfo copyWithZone:zone];
    return cred;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super init];
    if (self) {
        _token = [coder decodeObjectForKey:@"token"];
        _estimatedExpireDate = [coder decodeObjectForKey:@"estimatedExpireDate"];
        _platform = [coder decodeIntegerForKey:@"platform"];
        _customInfo = [coder decodeObjectForKey:@"customInfo"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.token forKey:@"token"];
    [aCoder encodeObject:self.estimatedExpireDate forKey:@"estimatedExpireDate"];
    [aCoder encodeInteger:self.platform forKey:@"platform"];
    [aCoder encodeObject:self.customInfo forKey:@"customInfo"];
}

@end
