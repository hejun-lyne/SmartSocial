//
//  IATHShareProtocol.h
//  ATHContext
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 YY. All rights reserved.
//

#ifndef IATHShareProtocol_h
#define IATHShareProtocol_h

#import "ATHSocialDefines.h"
#import "IATHShareInfo.h"
#import "ATHSocialBaseUserInfo.h"
#import "ATHSocialAuthCredential.h"

@class UIImage;
/**
 Social Service UI 代理，由于部分平台的授权/分享，需要在应用内 present/push,因此需要业务层实现该代理，确保能够正常展示三方界面
 */
@protocol IATHSocialUIDelegate <NSObject>
/**
 返回当前应用可用来做 push 的 vc，若返回的是 NavigationController，则会直接 push，否则，会调用 vc.navigationController push

 @return 当前应用可用来做 push 的 vc
 */
- (UIViewController *)viewControllerForPush;

/**
 返回当前应用可以用来 present 的 vc，将会直接调用 [vc presentViewController]

 @return 当前应用可以用来 present 的 vc
 */
- (UIViewController *)viewControllerForPresent;
@end


/**
 日志输出代理
 */
@protocol IATHSocialLoggerDelegate <NSObject>
- (void)log:(NSString *)format,... NS_FORMAT_FUNCTION(1, 2);
@end

/**
 WebImage 代理，对于分享网络图片的场景，大概率是客户端已经存储了该图片的 UIImage，此时若能直接提供给 Service，则可以免去下载过程。若业务层不实现此代理，或是某张图片在本地没有缓存，则 Service 内部将进行图片下载。
 */
@protocol IATHSocialWebImageDelegate <NSObject>
@optional

/**
 根据图片 URL，返回缓存的 UIImage 对象

 @param imageURL 图片 URL
 @return 缓存的 UIImage，为 nil 则内部会自动下载
 */
- (UIImage *)imageForURLString:(NSString *)imageURL;
@end

@protocol IATHSocial <NSObject>

@required

/**
 注册三方平台，初始化 Service

 @param platforms 三方平台的 NS_OPTIONS，用位或来注册多个平台
 @param platformConfig 三方平台初始化的必要配置信息，请使用 NSDictionary+SocialParameters 分类方法设置
 */
- (void)registerSocialPlatforms:(ATHSocialPlatform)platforms withConfiguration:(NSDictionary *)platformConfig;


/**
 分享到三方平台的固定渠道

 @param channel 分享渠道
 @param info 分享协议对象
 @param completion 分享结果回调
 */
- (void)shareToChannel:(ATHShareChannel)channel
                  info:(id<IATHShareInfo>)info
            completion:(void(^)(BOOL success, NSError *error))completion;


/**
 请求三方平台的授权

 @param platform 三方平台
 @param extendInfo 额外信息
 @param authCompletion 授权结果回调
 */
- (void)requestAuthForPlatform:(ATHSocialPlatform)platform
                    extendInfo:(NSDictionary *)extendInfo
                authCompletion:(void(^)(ATHSocialAuthCredential *credential, NSError *error))authCompletion;


/**
 请求三方平台用户信息，若未授权，会自动先走授权流程

 @param platform 三方平台
 @param userInfoCompletion 用户信息结果回调
 */
- (void)requestUserInfoForPlatform:(ATHSocialPlatform)platform completion:(void(^)(ATHSocialBaseUserInfo *userInfo, NSError *error))userInfoCompletion;

/**
 Service 内部应有对授权 token 的存储管理，调用此接口来清除存储，以便再次调用 requestAuthForPlatform 时，用户可以重新进行授权

 @param platforms 三方平台 NS_OPTIONS，用位或指定多个平台
 */
- (void)cleanAuthCacheForPlatforms:(ATHSocialPlatform)platforms;


/**
 对应 AppDelegate 回调的对应方法，转发至 Service 以便处理三方应用回调
 */
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation;
/**
 对应 AppDelegate 回调的对应方法，转发至 Service 以便处理三方应用回调
 */
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;
/**
 对应 AppDelegate 回调的对应方法，转发至 Service 以便处理三方应用回调
 */
- (void)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;


@property (nonatomic, weak) id <IATHSocialUIDelegate> uiDelegate;
@property (nonatomic, weak) id <IATHSocialLoggerDelegate> loggerDelegate;
@property (nonatomic, weak) id <IATHSocialWebImageDelegate> webImageDelegate;

@end

#endif /* IATHShareProtocol_h */
