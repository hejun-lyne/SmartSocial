//
//  IATHShareInfo.h
//  ATHContext
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 YY. All rights reserved.
//

#ifndef IATHShareInfo_h
#define IATHShareInfo_h

typedef NS_ENUM(NSUInteger, ATHShareImageFormat) {
    ATHShareImageFormatJPEG,
    ATHShareImageFormatPNG
};

@class UIImage;

/**
 分享信息的协议对象，由于不同三方平台存在差异性，下面的字段并不一定会在分享平台上显示（譬如 instagram 不支持任何文本，Facebook 不支持预设文案）。
 */
@protocol IATHShareInfo <NSObject>
//分享标题
@property (nonatomic, strong) NSString *title;
//分享副标题
@property (nonatomic, strong) NSString *subTitle;
//分享内容
@property (nonatomic, strong) NSString *content;
//分享 url 链接
@property (nonatomic, strong) NSString *url;
//分享图片数组（支持 NSString 和 UIImage）
@property (nonatomic, strong) NSArray <id> *shareImages;
//图片格式，默认为 JPEG
@property (nonatomic, assign) ATHShareImageFormat preferredImageFormat;

@end

#endif /* IATHShareInfo_h */
