//
//  ATHSocialBaseUserInfo.m
//  ATHContext
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018 YY. All rights reserved.
//

#import "ATHSocialBaseUserInfo.h"

@implementation ATHSocialBaseUserInfo

@end
