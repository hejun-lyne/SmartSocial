//
//  ATHSocialPlatform.h
//  ATHContext
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 YY. All rights reserved.
//

#ifndef ATHSocialDefines_h
#define ATHSocialDefines_h

extern NSString * const kTokenSecretKey;
extern NSString * const kUserIdKey;

typedef NS_ENUM (NSInteger, ATHShareChannel) {
    ATHShareChannelInvalid            = 0,
    ATHShareChannelSinaWeibo          = 1,
    ATHShareChannelWechatFriend       = 2,
    ATHShareChannelWechatMoments      = 3,
    ATHShareChannelQQFriend           = 4,
    ATHShareChannelQQZone             = 5,
    ATHShareChannelFacebook           = 6,
    ATHShareChannelTwitter            = 7,
    ATHShareChannelInstagram          = 8,
    ATHShareChannelVK                 = 9,
};

typedef NS_OPTIONS(NSInteger, ATHSocialPlatform) {
    ATHSocialPlatformInvalid    = 0,
    ATHSocialPlatformSinaWeibo  = 1 << 0,
    ATHSocialPlatformWechat     = 1 << 1,
    ATHSocialPlatformQQ         = 1 << 2,
    ATHSocialPlatformGoogle     = 1 << 3,
    ATHSocialPlatformFacebook   = 1 << 4,
    ATHSocialPlatformTwitter    = 1 << 5,
    ATHSocialPlatformInstagram  = 1 << 6,
    ATHSocialPlatformVK         = 1 << 7,
    ATHSocialPlatformTwitch     = 1 << 8,
    
    ATHSocialPlatformAll        = NSIntegerMax
};

typedef NS_ENUM(NSInteger, ATHSocialAuthErrorCode) {
    ATHSocialAuthErrorCodeSDKError     = -1,
    ATHSocialAuthErrorCodeCancelled    = -2,
};


typedef NS_ENUM(NSInteger, ATHSocialShareErrorCode) {
    ATHSocialShareErrorCodeSDKError     = -1,
    ATHSocialShareErrorCodeCancelled    = -2,
    ATHSocialShareErrorCodeAppNotInstalled  = -3,
};

typedef NS_ENUM(NSInteger, ATHAuthPolicy) {
    ATHAuthPolicySSOOnly       = 0,
    ATHAuthPolicyAll           = 1,
};

#endif /* ATHSocialDefines_h */
