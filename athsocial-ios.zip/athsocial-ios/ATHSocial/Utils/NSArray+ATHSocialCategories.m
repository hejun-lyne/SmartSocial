//
//  NSArray+ATHSocialCategories.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/13.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "NSArray+ATHSocialCategories.h"

@implementation NSArray (ATHSocialCategories)

- (NSArray *)athsocial_map:(id(^)(id obj))mapper
{
    NSMutableArray *retArray = [NSMutableArray new];
    [self enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        id res = mapper(obj);
        if (res) {
            [retArray addObject:res];
        }
    }];
    
    return [retArray copy];
}

@end
