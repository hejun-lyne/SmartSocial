//
//  NSArray+ATHSocialCategories.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/13.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSArray <ObjectType> (ATHSocialCategories)

- (NSArray *)athsocial_map:(id(^)(ObjectType obj))mapper;

@end
