//
//  ATHSocialWebImageManager.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/12.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>

@class UIImage;
@interface ATHSocialWebImageManager : NSObject

+ (void)getImageWithURL:(NSString *)URLString completion:(void(^)(UIImage *image, NSError *error))completion;

+ (void)getImagesWithArray:(NSArray <id> *)imageObjectArray completion:(void(^)(NSArray <UIImage *> *images, NSError *error))completion;

@end
