//
//  ATHSocialUtils.m
//  ATHSocial
//
//  Created by Gocy on 2018/7/14.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialUtils.h"

@implementation ATHSocialUtils

+ (NSDictionary *)dictFromQuery:(NSString *)query
{
    NSArray *items = [query componentsSeparatedByString:@"&"];
    NSMutableDictionary *resDict = [NSMutableDictionary new];
    for (NSString *item in items) {
        NSArray *keyval = [item componentsSeparatedByString:@"="];
        if (keyval.count != 2) {
            continue;
        }
        [resDict setObject:keyval[1] forKey:keyval[0]];
    }
    return [resDict copy];
}

@end
