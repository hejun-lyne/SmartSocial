//
//  ATHSocialWebImageManager.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/12.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialWebImageManager.h"

static NSString * const kATHSocialWebImageManagerDownloadError = @"ATHSocialWebImageManagerDownloadError";

@interface ATHSocialImageObject : NSObject
@property (nonatomic, strong) UIImage *image;
@end

@implementation ATHSocialWebImageManager

+ (void)getImageWithURL:(NSString *)URLString completion:(void (^)(UIImage *, NSError *))completion
{
    if (!completion) {
        return ;
    }
    UIImage *cachedImage = [IMAGE_SERVICE imageForURLString:URLString];
    if (cachedImage) {
        completion(cachedImage, nil);
    }
    
    [[[NSURLSession sharedSession] downloadTaskWithURL:[NSURL URLWithString:URLString] completionHandler:^(NSURL * _Nullable location, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error || !location) {
            completion(nil, error);
            return ;
        }
        NSData *imageData = [NSData dataWithContentsOfURL:location];
        UIImage *image = [[UIImage alloc] initWithData:imageData];
        completion(image, nil);
    }] resume];
}

+ (void)getImagesWithArray:(NSArray<id> *)imageObjectArray completion:(void (^)(NSArray<UIImage *> *, NSError *))completion
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        dispatch_group_t downloadGroup = dispatch_group_create();
        NSMutableArray <ATHSocialImageObject *> *downloadedImageObjects = [NSMutableArray new]; // 就是为了保持顺序而已
        for (id imageObject in imageObjectArray) {
            ATHSocialImageObject *obj = [ATHSocialImageObject new];
            [downloadedImageObjects addObject:obj];
            if ([imageObject isKindOfClass:[NSString class]]) {
                dispatch_group_enter(downloadGroup);
                [self getImageWithURL:imageObject completion:^(UIImage *image, NSError *error) {
                    if (error) {
                        [LOGGER log:@"ATHWebImage error downloading image for [%@], error: %@",imageObject,error];
                    }
                    obj.image = image;
                    dispatch_group_leave(downloadGroup);
                }];
            }else {
                obj.image = imageObject;
            }
        }
        
        dispatch_group_notify(downloadGroup, dispatch_get_main_queue(), ^{
            __block NSError *downloadError = nil;
            NSArray *res = [downloadedImageObjects athsocial_map:^id(ATHSocialImageObject *obj) {
                if (obj.image == nil && !downloadError) {
                    downloadError = [NSError errorWithDomain:kATHSocialWebImageManagerDownloadError code:-1 userInfo:@{@"reason": @"some image is nil and will be abandoned."}];
                }
                return obj.image;
            }];
            
            completion(res, downloadError);
        });
    });
}

@end


@implementation ATHSocialImageObject

@end
