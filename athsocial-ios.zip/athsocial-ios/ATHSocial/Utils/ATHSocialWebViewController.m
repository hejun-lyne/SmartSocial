//
//  ATHSocialWebViewController.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/8.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialWebViewController.h"

@interface ATHSocialWebViewController (){}



@end

@implementation ATHSocialWebViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        _webview = [[WKWebView alloc] init];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.webview.frame = self.view.bounds;
    self.webview.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    [self.view addSubview:self.webview];
}

- (void)setCancelBlock:(void (^)(void))cancelBlock
{
    if (_cancelBlock == cancelBlock) {
        return ;
    }
    _cancelBlock = [cancelBlock copy];
    [self updateLeftBarItem];
}


- (void)updateLeftBarItem
{
    if (self.cancelBlock) {
        UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(didClickCancel)];
        self.navigationItem.leftBarButtonItem = item;
    }else{
        self.navigationItem.leftBarButtonItem = nil;
    }
}

- (void)didClickCancel
{
    if (self.cancelBlock) {
        self.cancelBlock();
    }
}

@end
