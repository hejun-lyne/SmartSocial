//
//  ATHSocialCredentialStorage.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/7.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialCredentialStorage.h"

#define PLATFORM_NAME(key) @#key
@implementation ATHSocialCredentialStorage

+ (void)storeCredential:(ATHSocialAuthCredential *)credential
{
    NSString *key = [self _keyForPlatform:credential.platform];
    NSData *credData = [NSKeyedArchiver archivedDataWithRootObject:credential];
    
    [[NSUserDefaults standardUserDefaults] setObject:credData forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (ATHSocialAuthCredential *)credentialForPlatform:(ATHSocialPlatform)platform
{
    NSString *key = [self _keyForPlatform:platform];
    NSData *credData = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    return [NSKeyedUnarchiver unarchiveObjectWithData:credData];
}

+ (void)deleteCredentialForPlatform:(ATHSocialPlatform)platform
{
    [LOGGER log:@"Deleting auth cache for: %li",platform];
    NSString *key = [self _keyForPlatform:platform];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (NSString *)_keyForPlatform:(ATHSocialPlatform)platform
{
    return [NSString stringWithFormat:@"ATHSocialPlatform_%li",platform];
}

@end
