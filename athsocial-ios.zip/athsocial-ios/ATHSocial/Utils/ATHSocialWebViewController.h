//
//  ATHSocialWebViewController.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/8.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WKWebView.h>

//NS_ASSUME_NONNULL_BEGIN

@interface ATHSocialWebViewController : UIViewController

@property (nonatomic, strong) WKWebView *webview;

@property (nonatomic, copy) void(^cancelBlock)(void);

@end

//NS_ASSUME_NONNULL_END
