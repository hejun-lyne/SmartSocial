//
//  ATHSocialCredentialStorage.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/7.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface ATHSocialCredentialStorage : NSObject

+ (void)storeCredential:(ATHSocialAuthCredential *)credential;

+ (ATHSocialAuthCredential *)credentialForPlatform:(ATHSocialPlatform)platform;

+ (void)deleteCredentialForPlatform:(ATHSocialPlatform)platform;

@end

NS_ASSUME_NONNULL_END
