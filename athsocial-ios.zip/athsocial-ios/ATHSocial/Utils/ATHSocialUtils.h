//
//  ATHSocialUtils.h
//  ATHSocial
//
//  Created by Gocy on 2018/7/14.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ATHSocialUtils : NSObject

+ (NSDictionary *)dictFromQuery:(NSString *)query;

@end

