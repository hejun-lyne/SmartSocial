//
//  ATHSocial.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ATHContext.h"

//! Project version number for ATHSocial.
FOUNDATION_EXPORT double ATHSocialVersionNumber;

//! Project version string for ATHSocial.
FOUNDATION_EXPORT const unsigned char ATHSocialVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ATHSocial/PublicHeader.h>

extern NSString * ATHSocialOnLogoutAndRemoveAllTokens;


#define LOGGER [[ATHSocial sharedInstance] loggerDelegate]
#define IMAGE_SERVICE [[ATHSocial sharedInstance] webImageDelegate]

#import "IATHShareInfo.h"
#import "IATHSocial.h"
#import "NSDictionary+SocialParameters.h"
#import "ATHSocialAuthCredential.h"
#import "ATHSocialBaseUserInfo.h"
#import "ATHSocialDefines.h"

@interface ATHSocial : NSObject <IATHSocial>
ATH_SINGLETON_DECLARE


@end
