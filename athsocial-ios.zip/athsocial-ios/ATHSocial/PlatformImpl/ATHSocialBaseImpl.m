//
//  ATHSocialBaseImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialBaseImpl.h"

NSTimeInterval const kExpiredThreshold = 2 * 24 * 60 * 60; // 两天

//TODO: 监听 becomeActive 通知，回调 各种 fail
@implementation ATHSocialBaseImpl

- (instancetype)init
{
    self = [super init];
    if (self) {
        _authCompletionCallbacks = [NSMutableArray new];
        _userInfoCompletionCallbacks = [NSMutableArray new];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)config:(NSDictionary *)configDict
{
}


- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError * _Nonnull))authCompletion
{
    if (authCompletion) {
        @synchronized (self) {
            [self.authCompletionCallbacks addObject:authCompletion];
        }
    }
}

- (void)requestUserInfoWithCompletion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    if (userInfoCompletion) {
        @synchronized (self) {
            [self.userInfoCompletionCallbacks addObject:userInfoCompletion];
        }
    }
}

- (void)shareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError * _Nonnull))completion
{
    self.shareCompletion = completion;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation
{
    return NO;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    return NO;
}

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    
}

- (BOOL)hasUserInfoQueryCallback
{
    __block BOOL res = NO;
    @synchronized (self) {
        res = self.userInfoCompletionCallbacks.count > 0;
    }
    return res;
}

#pragma mark - Notifications

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    
}

@end


@implementation ATHSocialAuthCredential (ATHDateCheck)

- (BOOL)stillValid
{
    if (self.platform == ATHSocialPlatformTwitter || self.platform == ATHSocialPlatformInstagram) {
        /*
         How long does an access token last?
         Access tokens are not explicitly expired. An access token will be invalidated if a user explicitly revokes an application in the their Twitter account settings, or if Twitter suspends an application. If an application is suspended, there will be a note on the apps.twitter.com page stating that it has been suspended.
         推特的 token 不会过期。。。。
         https://twittercommunity.com/t/accesstoken-gets-expired-frequently/70522
         但是又有人说可能过期，wtf？
         */
        return YES;
    }
    if (self.estimatedExpireDate == nil) {
        return NO;
    }
    
    
    //暂时按两天来算
    NSDate *today = [NSDate date];
    NSTimeInterval gap = [self.estimatedExpireDate timeIntervalSinceDate:today];
    
    BOOL isShortPeriodToken = self.platform == ATHSocialPlatformGoogle || self.platform == ATHSocialPlatformTwitch;
    
    //实测谷歌 token 特别短，只有一个多小时，所以按半个小时来
    NSTimeInterval threshold = isShortPeriodToken ? 30 * 60 : kExpiredThreshold;
    
    if (gap <= 0 || gap < threshold) {
        return NO;
    }
    return YES;
}

@end
