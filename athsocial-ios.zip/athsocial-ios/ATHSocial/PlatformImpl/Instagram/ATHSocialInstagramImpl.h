//
//  ATHSocialInstagramImpl.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/13.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialBaseImpl.h"

@interface ATHSocialInstagramImpl : ATHSocialBaseImpl

@end
