//
//  ATHSocialInstagramImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/13.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialInstagramImpl.h"
#import "ATHSocialCredentialStorage.h"
#import "ATHSocialWebViewController.h"
#import "ATHSocialWebImageManager.h"
#import "ATHSocialUtils.h"

#import <WebKit/WKNavigationDelegate.h>
#import <WebKit/WKNavigationAction.h>


/*
 
 Even though our access tokens do not specify an expiration time, your app should handle the case that either the user revokes access, or Instagram expires the token after some period of time. If the token is no longer valid, API responses will contain an “error_type=OAuthAccessTokenException”. In this case you will need to re-authenticate the user to obtain a new valid token.
 In other words: do not assume your access_token is valid forever.
 
....
 */

static NSString * const kATHSocialInstagramAuthError = @"ATHSocialInstagramAuthError";
static NSString * const kATHSocialInstagramShareError = @"ATHSocialInstagramShareError";
static NSString * const kATHSocialInstagramUserInfoError = @"ATHSocialInstagramUserInfoError";

@interface ATHSocialInstagramImpl ()<WKNavigationDelegate, UIDocumentInteractionControllerDelegate>

@property (nonatomic, copy) ATHSocialImplViewControllerGenerator vcGenerator;
@property (nonatomic, weak) UIViewController *authWebViewController;
@property (nonatomic, strong) NSString *clientId;
@property (nonatomic, strong) NSString *redirectUrl;
@property (nonatomic, strong) ATHSocialAuthCredential *currentCredential;
@property (nonatomic, strong) UIDocumentInteractionController *docController;

@end

@implementation ATHSocialInstagramImpl

- (void)config:(NSDictionary *)configDict
{
    NSString *EXTRACT_CONFIG(clientId);
    NSString *EXTRACT_CONFIG(redirectUrl);
    ATHSocialImplViewControllerGenerator EXTRACT_CONFIG(viewControllerGenerator);
    
    _clientId = clientId;
    _redirectUrl = redirectUrl;
    _vcGenerator = [viewControllerGenerator copy];
}

- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError *))authCompletion
{
    [super requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion];
    
    ATHSocialAuthCredential *credential = [ATHSocialCredentialStorage credentialForPlatform:ATHSocialPlatformInstagram];
    if ([credential stillValid]) {
        self.currentCredential = credential;
        AUTH_COMPLETE(credential, nil);
        return ;
    }
    [self _openAuthWebView];
}

- (void)requestUserInfoWithCompletion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    [super requestUserInfoWithCompletion:userInfoCompletion];
    if (self.currentCredential) {
        [self _getUserInfo];
    }else {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            if (error) {
                USERINFO_COMPLETE(nil, error);
                return ;
            }
            [self _getUserInfo];
        }];
    }
}


- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    [super onLogoutAndRemoveAllTokens:platform];
    if ((platform & ATHSocialPlatformTwitter) == 0) {
        return ;
    }
    self.currentCredential = nil;
    [ATHSocialCredentialStorage deleteCredentialForPlatform:ATHSocialPlatformInstagram];
}

- (void)shareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    [super shareWithInfo:info completion:completion];
    if (![[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"instagram://"]]) {
        SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialInstagramShareError code:ATHSocialShareErrorCodeAppNotInstalled userInfo:nil]);
        return ;
    }
    if (info.shareImages.count <= 0) {
        SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialInstagramShareError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Instagram share must contain image."}]);
        return ;
    }
    
    id imageObject = info.shareImages.firstObject;
    if ([imageObject isKindOfClass:[NSString class]]) {
        [ATHSocialWebImageManager getImageWithURL:imageObject completion:^(UIImage *image, NSError *error) {
            [self _shareWithImage:image format:info.preferredImageFormat];
        }];
    }else {
        [self _shareWithImage:imageObject format:info.preferredImageFormat];
    }
}

#pragma mark - Helpers

- (void)_openAuthWebView
{
    if (self.authWebViewController) {
        return;
    }
    ATHSocialWebViewController *webVc = [ATHSocialWebViewController new];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:webVc];
    
    NSString *encodedRedirectUrl = [self.redirectUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet alphanumericCharacterSet]];
    NSString *authUrl = [NSString stringWithFormat:@"https://api.instagram.com/oauth/authorize/?client_id=%@&redirect_uri=%@&response_type=token",self.clientId, encodedRedirectUrl];
    
    webVc.webview.navigationDelegate = self;
    [webVc.webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:authUrl]]];
    webVc.title = @"Instagram";
    __weak UIViewController *weaknav = nav;
    webVc.cancelBlock = ^{
        NSError *cancelError = [NSError errorWithDomain:kATHSocialInstagramAuthError code:ATHSocialAuthErrorCodeCancelled userInfo:nil];
        
        AUTH_COMPLETE(nil, cancelError);
        [weaknav.presentingViewController dismissViewControllerAnimated:YES completion:nil];
        self.authWebViewController = nil;
    };
    self.authWebViewController = nav;
    [self.vcGenerator() presentViewController:nav animated:YES completion:nil];
}

- (void)_shareWithImage:(UIImage *)image format:(ATHShareImageFormat)format
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *filePath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"ath_insshare.igo"];
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
        NSData *imgData = format == ATHShareImageFormatPNG ? UIImagePNGRepresentation(image) : UIImageJPEGRepresentation(image, 1.0);
        BOOL writeSuccess = [imgData writeToFile:filePath atomically:YES];
        if (!writeSuccess) {
            SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialInstagramShareError code:ATHSocialShareErrorCodeSDKError userInfo:nil]);
            return ;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self _showDocumentPreviewWithPath:filePath];
        });
    });
}

- (void)_showDocumentPreviewWithPath:(NSString *)path
{
    [self.docController dismissMenuAnimated:YES];
    self.docController = nil;
    UIDocumentInteractionController *docController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:path]];
    docController.delegate = self;
    docController.UTI = @"com.instagram.exclusivegram";
    self.docController = docController;
    [docController presentOpenInMenuFromRect:CGRectZero inView:self.vcGenerator().view animated:YES];
}

- (void)_handleAccessToken:(NSString *)tokenResultString
{
    NSDictionary *resDict = [ATHSocialUtils dictFromQuery:tokenResultString];
    NSString *accessToken = resDict[@"access_token"];
    
    [self _dismissAuthWebView];
    if (!accessToken) {
        NSError *error = [NSError errorWithDomain:kATHSocialInstagramAuthError code:ATHSocialAuthErrorCodeCancelled userInfo:nil];
        AUTH_COMPLETE(nil, error);
        [LOGGER log:@"InstagramImpl accessToken invalid: %@", tokenResultString];
        return ;
    }
    
    ATHSocialAuthCredential *credential = [ATHSocialAuthCredential new];
    credential.token = accessToken;
    credential.platform = ATHSocialPlatformInstagram;
    //no expr date....
    
    [ATHSocialCredentialStorage storeCredential:credential];
    self.currentCredential = credential;
    AUTH_COMPLETE(credential, nil);
    
    [self _getUserInfo];
}

- (void)_getUserInfo
{
    if (!self.currentCredential || !NEED_FETCH_USERINFO) {
        return;
    }
    
    NSString *reqUrl = [NSString stringWithFormat:@"https://api.instagram.com/v1/users/self/?access_token=%@", self.currentCredential.token];
    [[[NSURLSession sharedSession] dataTaskWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:reqUrl]] completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) {
            USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialInstagramUserInfoError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"user info request failed."}]);
            [LOGGER log:@"InstagramImpl request users/self error: %@", error];
        }
        NSError *serializationError;
        NSDictionary *resDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&serializationError];
        
        if (serializationError) {
            [LOGGER log:@"InstagramImpl serialize error %@",serializationError];
            USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialInstagramUserInfoError code:ATHSocialShareErrorCodeSDKError userInfo:@{@"reason": @"user info request succeed, but serialization failed."}]);
            return ;
        }
        
        NSDictionary *dataDict = resDict[@"data"];
        ATHSocialBaseUserInfo *info = [ATHSocialBaseUserInfo new];
        info.nickname = dataDict[@"username"];
        info.gender = ATHSocialUserGenderUnknown;
        info.uid = [NSString stringWithFormat:@"%li", [dataDict[@"id"] integerValue]];
        info.signature = dataDict[@"bio"];
        info.avatarUrl = dataDict[@"profile_picture"];
        USERINFO_COMPLETE(info, nil);
    }] resume] ;
}


- (void)_dismissAuthWebView
{
    if (!self.authWebViewController) {
        return ;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.authWebViewController) {
            [self.authWebViewController.presentingViewController dismissViewControllerAnimated:YES completion:nil];
            self.authWebViewController = nil;
        }
    });
}

#pragma mark - UIDocumentInteractionControllerDelegate
- (void)documentInteractionControllerDidDismissOpenInMenu:(UIDocumentInteractionController *)controller
{
    if (controller != self.docController) {
        return ;
    }
    //正常点了分享，会先走 willBegin，那就会清空 self.completion 了。
    self.docController = nil;
    SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialInstagramShareError code:ATHSocialShareErrorCodeCancelled userInfo:nil]);
}

- (void)documentInteractionController:(UIDocumentInteractionController *)controller willBeginSendingToApplication:(NSString *)application
{
    if (controller != self.docController) {
        return ;
    }
    if ([application containsString:@"instagram"]) {
        //分享到了 ins
        SHARE_COMPLETE(YES, nil);
    }else {
        [LOGGER log:@"InstagramImpl user share to :%@",application];
        SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialInstagramShareError code:ATHSocialShareErrorCodeCancelled userInfo:@{@"reason": @"User did not click instagram on the menu."}]);
    }
}



#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    if ([navigationAction.request.URL.absoluteString hasPrefix:self.redirectUrl]) {
        
        NSURLComponents *urlComponents = [[NSURLComponents alloc] initWithURL:navigationAction.request.URL resolvingAgainstBaseURL:YES];
        [self _handleAccessToken:urlComponents.fragment?:urlComponents.query];
        
        decisionHandler(WKNavigationActionPolicyCancel);
        return ;
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

@end
