//
//  ATHSocialBaseImpl.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>

#define AUTH_COMPLETE(credential, error) \
do {\
NSArray *ath_authcallbacks = nil;\
@synchronized (self) {\
ath_authcallbacks = [self.authCompletionCallbacks copy];\
[self.authCompletionCallbacks removeAllObjects];\
}\
dispatch_async(dispatch_get_main_queue(), ^{\
for (void(^authCallback)(ATHSocialAuthCredential *,NSError *) in ath_authcallbacks) {\
authCallback(credential, error);\
}\
});\
}while(0)

#define SHARE_COMPLETE(success, error) \
do { \
dispatch_async(dispatch_get_main_queue(), ^{\
if (self.shareCompletion) {\
self.shareCompletion(success, error);\
self.shareCompletion = nil;\
}\
});\
}while(0)

#define USERINFO_COMPLETE(info, error) \
do {\
NSArray *ath_userinfocallbacks = nil;\
@synchronized (self) {\
ath_userinfocallbacks = [self.userInfoCompletionCallbacks copy];\
[self.userInfoCompletionCallbacks removeAllObjects];\
}\
dispatch_async(dispatch_get_main_queue(), ^{\
for (void(^userInfoCallback)(ATHSocialBaseUserInfo *,NSError *) in ath_userinfocallbacks) {\
    userInfoCallback(info, error);\
}\
});\
}while(0)

#define EXTRACT_CONFIG(key) key = configDict[@""#key""]

#define NEED_FETCH_USERINFO [self hasUserInfoQueryCallback]

typedef UIViewController * (^ATHSocialImplViewControllerGenerator)(void);

@interface ATHSocialBaseImpl : NSObject

- (void)config:(NSDictionary *)configDict;

- (void)shareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion;

- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError *))authCompletion;

- (void)requestUserInfoWithCompletion:(void(^)(ATHSocialBaseUserInfo *userInfo, NSError *error))userInfoCompletion;

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation;

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options;

- (void)applicationDidBecomeActive:(UIApplication *)application;

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform;

- (BOOL)hasUserInfoQueryCallback;

@property (nullable, nonatomic, copy) void (^shareCompletion)(BOOL, NSError *);

@property (nonatomic, strong) NSMutableArray *authCompletionCallbacks;
@property (nonatomic, strong) NSMutableArray *userInfoCompletionCallbacks;

@end


@interface ATHSocialAuthCredential (ATHDateCheck)
- (BOOL)stillValid;
@end

//NS_ASSUME_NONNULL_END
