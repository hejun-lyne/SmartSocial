//
//  ATHSocialVKImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/13.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialVKImpl.h"
#import <VK-ios-sdk/VKSdk.h>

#import "ATHSocialWebImageManager.h"

static NSString * const kATHSocialVKAuthError = @"ATHSocialVKAuthError";
static NSString * const kATHSocialVKUserInfoError = @"ATHSocialVKUserInfoError";
static NSString * const kATHSocialVKShareError = @"ATHSocialVKShareError";

@interface ATHSocialVKImpl () <VKSdkDelegate, VKSdkUIDelegate>

@property (nonatomic, strong) NSString *appId;
@property (nonatomic, copy) ATHSocialImplViewControllerGenerator vcGenerator;
@property (nonatomic, strong) VKSdk *vkSdkInstance;
@property (nonatomic, strong) VKAccessToken *currentToken;

@end

NSArray *permissions(){
    return @[VK_PER_WALL, VK_PER_PHOTOS];
}


@implementation ATHSocialVKImpl

- (void)config:(NSDictionary *)configDict
{
    NSString *EXTRACT_CONFIG(appId);
    ATHSocialImplViewControllerGenerator EXTRACT_CONFIG(viewControllerGenerator);
    
    self.vcGenerator = viewControllerGenerator;
    self.vkSdkInstance = [VKSdk initializeWithAppId:appId];
    [self.vkSdkInstance registerDelegate:self];
    [self.vkSdkInstance setUiDelegate:self];
}

- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError *))authCompletion
{
    [super requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion];
    [VKSdk wakeUpSession:permissions() completeBlock:^(VKAuthorizationState state, NSError *error) {
        if (error) {
            [LOGGER log:@"VKImpl wakeup session error: %@",error];
            NSError *wakeupError = [NSError errorWithDomain:kATHSocialVKAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:nil];
            AUTH_COMPLETE(nil, wakeupError);
            return ;
        }
        [self _handleAuthorizeState:state];
    }];
}

- (void)requestUserInfoWithCompletion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    [super requestUserInfoWithCompletion:userInfoCompletion];
    
    if (!self.currentToken.accessToken || [self.currentToken isExpired]) {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            if (error) {
                USERINFO_COMPLETE(nil, error);
                return ;
            }
            [self _getUserInfo];
        }];
    }else {
        [self _getUserInfo];
    }
}

- (void)shareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    [super shareWithInfo:info completion:completion];
    if (!self.currentToken.accessToken || [self.currentToken isExpired]) {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            [self _doShareWithInfo:info completion:completion];
        }];
    }else {
        [self _doShareWithInfo:info completion:completion];
    }
}

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    [super onLogoutAndRemoveAllTokens:platform];
    if ((platform & ATHSocialPlatformVK) == 0) {
        return ;
    }
    [LOGGER log:@"VK cleanning everything."];
    [VKSdk forceLogout];
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation
{
    BOOL handled = [VKSdk processOpenURL:url fromApplication:sourceApp];
    [LOGGER log:@"VKImpl handle url(sourceapp) [%@], res: %i",url.absoluteString,handled];
    return handled;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    BOOL handled = [VKSdk processOpenURL:url fromApplication:options[UIApplicationOpenURLOptionsSourceApplicationKey]];
    [LOGGER log:@"VKImpl handle url(options) [%@], res: %i",url.absoluteString,handled];
    return handled;
}

#pragma mark - Helpers

- (void)_doShareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    void (^shareWithImages)(NSArray <UIImage *> *) = ^(NSArray <UIImage *> *images){
        VKShareLink *sharelink = info.url.length > 0 ? [[VKShareLink alloc] initWithTitle:nil link:[NSURL URLWithString:info.url]] : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            VKShareDialogController *dialog = [VKShareDialogController new];
            dialog.text = info.content;
            dialog.shareLink = sharelink;
            dialog.requestedScope = permissions();
            if (images.count > 0) {
                VKImageParameters *sharedParam = info.preferredImageFormat == ATHShareImageFormatPNG ? [VKImageParameters pngImage] : [VKImageParameters jpegImageWithQuality:1.0];
                dialog.uploadImages = [images athsocial_map:^id(UIImage *obj) {
                    return [VKUploadImage uploadImageWithImage:obj andParams:sharedParam];
                }];
            }
            dialog.dismissAutomatically = YES;
            dialog.completionHandler = ^(VKShareDialogController *dialog, VKShareDialogControllerResult result) {
                [LOGGER log:@"VKImpl share result: %li",result];
                if (result == VKShareDialogControllerResultCancelled) {
                    SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialVKShareError code:ATHSocialShareErrorCodeCancelled userInfo:nil]);
                    return ;
                }
                SHARE_COMPLETE(YES, nil);
            };
            [self.vcGenerator() presentViewController:dialog animated:YES completion:nil];
        });
    };
    
    if (info.shareImages.count > 0) {
        [ATHSocialWebImageManager getImagesWithArray:info.shareImages
                                           completion:^(NSArray<UIImage *> *images, NSError *error) {
                                               shareWithImages(images);
                                           }];
    }else {
        shareWithImages(nil);
    }
}

- (void)_handleAuthorizeState:(VKAuthorizationState)state
{
    [LOGGER log:@"VKImpl VKSdk state: %lu",state];
    switch (state) {
        case VKAuthorizationAuthorized:
        {
            [self _authComplete];
            break;
        }
            
        case VKAuthorizationInitialized:
        {
            [VKSdk authorize:permissions() withOptions:VKAuthorizationOptionsUnlimitedToken|VKAuthorizationOptionsDisableSafariController];
            break;
        }
        default:
        {
            NSError *sdkError = [NSError errorWithDomain:kATHSocialVKAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"VKSDK state is invalid."}];
            AUTH_COMPLETE(nil, sdkError);
            break;
        }
    }
}

- (void)_authComplete
{
    self.currentToken = [VKSdk accessToken];
    ATHSocialAuthCredential *credential = [ATHSocialAuthCredential new];
    credential.platform = ATHSocialPlatformVK;
    credential.token = self.currentToken.accessToken;
    
    AUTH_COMPLETE(credential, nil);
}

- (void)_getUserInfo
{
    if (!NEED_FETCH_USERINFO) {
        return ;
    }

    [[[VKApi users] get:@{
                          @"user_ids": @[self.currentToken.userId],
                          @"fields": @[@"id",@"first_name",@"nickname",@"screen_name",@"sex",@"photo_max_orig",@"status"]
                          }] executeWithResultBlock:^(VKResponse *response) {
        if ([response.json isKindOfClass:[NSArray class]]) {
            NSDictionary *infoDict = [((NSArray *)response.json) firstObject];
            if ([infoDict isKindOfClass:[NSDictionary class]]) {
                ATHSocialBaseUserInfo *info = [ATHSocialBaseUserInfo new];
                
                info.uid = [NSString stringWithFormat:@"%li", [infoDict[@"id"] integerValue]];
                NSString *nickname = infoDict[@"nickname"];
                if (nickname.length <= 0) {
                    nickname = infoDict[@"screen_name"];
                    if (nickname.length <= 0) {
                        nickname = infoDict[@"first_name"];
                    }
                }
                info.nickname = nickname;
                info.gender = ATHSocialUserGenderUnknown;
                if (infoDict[@"sex"]) {
                    NSInteger sexValue = [infoDict[@"sex"] integerValue];
                    info.gender = sexValue == 2 ? ATHSocialUserGenderMale:ATHSocialUserGenderFemale;
                }
                info.signature = infoDict[@"status"];
                info.avatarUrl = infoDict[@"photo_max_orig"];
                
                USERINFO_COMPLETE(info, nil);
                return ;
            }
        }
        
        [LOGGER log:@"Error getting user info, got json: %@, str: %@",response.json, response.responseString];
        USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialVKUserInfoError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"VKApi invalid return value."}]);
    } errorBlock:^(NSError *error) {
        [LOGGER log:@"Error getting user info, VKApi error: %@",error];
        USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialVKUserInfoError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"VKApi internal error."}]);
    }];
}

#pragma mark - VKSdk Delegates

- (void)vkSdkAccessAuthorizationFinishedWithResult:(VKAuthorizationResult *)result {
    if (result.token) {
        [self _authComplete];
        if (result.token.localUser) {
            [self _getUserInfo];
        }
        return ;
    }
    [LOGGER log:@"VKImpl vkSdkAccessAuthorizationFinishedWithResult.error: %@",result.error];
    
    NSError *sdkError = [NSError errorWithDomain:kATHSocialVKAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:nil];
    AUTH_COMPLETE(nil, sdkError);
}

- (void)vkSdkUserAuthorizationFailed {
    [LOGGER log:@"VKImpl vkSdkUserAuthorizationFailed"];
    NSError *sdkError = [NSError errorWithDomain:kATHSocialVKAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:nil];
    AUTH_COMPLETE(nil, sdkError);
}

- (void)vkSdkAccessTokenUpdated:(VKAccessToken *)newToken oldToken:(VKAccessToken *)oldToken
{
    self.currentToken = newToken;
    if (newToken.localUser) {
        [self _getUserInfo];
    }
}

- (void)vkSdkNeedCaptchaEnter:(VKError *)captchaError {
    [LOGGER log:@"VKImpl, vkSdkNeedCaptchaEnter, errorCode: %li, msg: %@, reason: %@, textFromServer: %@",captchaError.errorCode, captchaError.errorMessage, captchaError.errorReason, captchaError.errorText];
}

- (void)vkSdkShouldPresentViewController:(UIViewController *)controller {
    [self.vcGenerator() presentViewController:controller animated:YES completion:nil];
}

@end
