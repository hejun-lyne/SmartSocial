//
//  ATHSocialWeiboImpl.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ATHSocialBaseImpl.h"

@interface ATHSocialWeiboImpl : ATHSocialBaseImpl

@end
