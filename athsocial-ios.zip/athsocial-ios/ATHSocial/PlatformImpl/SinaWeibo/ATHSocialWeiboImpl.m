//
//  ATHSocialWeiboImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#import "ATHSocialWeiboImpl.h"
#import "WeiboSDK.h"
#import "ATHSocialWebImageManager.h"
#import "ATHSocialCredentialStorage.h"

static NSString * const kATHSocialWeiboShareError = @"ATHSocialWeiboShareError";
static NSString * const kATHSocialWeiboAuthError = @"ATHSocialWeiboAuthError";

@interface ATHSocialWeiboImpl () <WeiboSDKDelegate, WBHttpRequestDelegate, WBMediaTransferProtocol>

@property (nonatomic, strong) NSString *redirectUrl;
@property (nonatomic, strong) NSString *appKey;
@property (nonatomic, strong) NSString *appSecret;
@property (nonatomic, assign) BOOL ssoOnly;

@property (nonatomic, strong) ATHSocialAuthCredential *currentCredential;
@property (nonatomic, strong) WBSendMessageToWeiboRequest *pendingWeiboShareRequest;


@end

@implementation ATHSocialWeiboImpl


- (void)config:(NSDictionary *)configDict
{
    NSString *EXTRACT_CONFIG(appKey);
    NSString *EXTRACT_CONFIG(appSecret);
    NSString *EXTRACT_CONFIG(redirectUrl);
    NSNumber *EXTRACT_CONFIG(ssoOnly);
    
    _appKey = appKey;
    _appSecret = appSecret;
    _redirectUrl = redirectUrl;
    _ssoOnly = [ssoOnly boolValue];
    
    [WeiboSDK registerApp:appKey];
}

- (void)shareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    
    [super shareWithInfo:info completion:completion];
    if (self.pendingWeiboShareRequest) {
        SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialWeiboShareError code:-1 userInfo:@{@"reason": @"Cannot share while another share request is in progress."}]);
        [LOGGER log:@"Weibo share error, pendingWeiboShareRequest is not nil"];
        return;
    }
    
    if (!self.currentCredential) {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            [self _doShareWithInfo:info completion:completion];
        }];
    }else {
        [self _doShareWithInfo:info completion:completion];
    }
}

- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError *))authCompletion
{
    
    [super requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion];
    if (self.currentCredential) {
        self.currentCredential = nil;
    }

    ATHSocialAuthCredential *credential = [ATHSocialCredentialStorage credentialForPlatform:ATHSocialPlatformSinaWeibo];
    
    if ([credential stillValid]) {
        
        [LOGGER log:@"SinaAuth using cached credential, expr: %@",credential.estimatedExpireDate];
        
        self.currentCredential = [credential copy];
        AUTH_COMPLETE(credential, nil);
        [self _refreshCurrentToken];
        return ;
    }
    
    WBAuthorizeRequest *authRequest = [WBAuthorizeRequest request];
    authRequest.scope = @"all";
    authRequest.redirectURI = self.redirectUrl;
    authRequest.shouldShowWebViewForAuthIfCannotSSO = !self.ssoOnly;
    [WeiboSDK sendRequest:authRequest];
    
}

- (void)requestUserInfoWithCompletion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    [super requestUserInfoWithCompletion:userInfoCompletion];
    
    if (!self.currentCredential) {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            if (error) {
                USERINFO_COMPLETE(nil, error);
                return ;
            }
            [self _getUserInfo];
        }];
    }else {
        [self _getUserInfo];
    }
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation
{
    BOOL handled = [WeiboSDK handleOpenURL:url delegate:self];
    [LOGGER log:@"WeiboImpl handle url: %@, res: %i",url.absoluteString,handled];
    return handled;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    BOOL handled = [WeiboSDK handleOpenURL:url delegate:self];
    [LOGGER log:@"WeiboImpl handle url: %@, res: %i",url.absoluteString,handled];
    return handled;
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    if ([WeiboSDK isCanShareInWeiboAPP]) {
        AUTH_COMPLETE(nil, [NSError errorWithDomain:kATHSocialWeiboAuthError code:ATHSocialAuthErrorCodeCancelled userInfo:nil]);
        SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialWeiboShareError code:ATHSocialShareErrorCodeCancelled userInfo:nil]);
    }
}

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    [super onLogoutAndRemoveAllTokens:platform];
    if ((platform & ATHSocialPlatformSinaWeibo) == 0) {
        return ;
    }
    if (self.currentCredential) {
        [WeiboSDK logOutWithToken:self.currentCredential.token delegate:self withTag:nil];
        self.currentCredential = nil;
    }
    [ATHSocialCredentialStorage deleteCredentialForPlatform:ATHSocialPlatformSinaWeibo];
}

#pragma mark - WeiboSDKDelegate

- (void)didReceiveWeiboRequest:(WBBaseRequest *)request
{
    NSLog(@"Not implemented");
}

- (void)didReceiveWeiboResponse:(WBBaseResponse *)response
{
    if ([response isKindOfClass:[WBAuthorizeResponse class]]) {
        WBAuthorizeResponse *weiboAuthResponse = (WBAuthorizeResponse *)response;
        if (response.statusCode != WeiboSDKResponseStatusCodeSuccess) {
            NSError *authError = [NSError errorWithDomain:kATHSocialWeiboAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Weibo auth failed."}];
            AUTH_COMPLETE(nil, authError);
            [LOGGER log:@"Weibo auth failed, statusCode: %li", response.statusCode];
            return ;
        }
        ATHSocialAuthCredential *credential = [ATHSocialAuthCredential new];
        credential.platform = ATHSocialPlatformSinaWeibo;
        credential.token = weiboAuthResponse.accessToken;
        credential.estimatedExpireDate = weiboAuthResponse.expirationDate;
        credential.customInfo = @{
                                  @"refreshToken": weiboAuthResponse.refreshToken?:@"",
                                  @"userID": weiboAuthResponse.userID?:@""
                                  };
        [LOGGER log:@"Weibo auth succeed, expr date: %@", weiboAuthResponse.expirationDate];
        [ATHSocialCredentialStorage storeCredential:credential];
        self.currentCredential = [credential copy];
        AUTH_COMPLETE(credential, nil);
        [self _getUserInfo];
    }else if ([response isKindOfClass:[WBSendMessageToWeiboResponse class]]){
        [LOGGER log:@"WeiboImpl share status code: %li", response.statusCode ];
        NSError *error = response.statusCode == WeiboSDKResponseStatusCodeSuccess ? nil : [NSError errorWithDomain:kATHSocialWeiboShareError code:response.statusCode == WeiboSDKResponseStatusCodeUserCancel ? ATHSocialShareErrorCodeCancelled : ATHSocialShareErrorCodeSDKError userInfo:@{@"reason": @"SDK status code failure."}];
        SHARE_COMPLETE(error == nil, error);
    }
}

#pragma mark - WeiboHTTPRequestDelegate

- (void)request:(WBHttpRequest *)request didFailWithError:(NSError *)error
{
    
    [LOGGER log:@"WeiboImpl request error: %@,reqTag: %@",error,request.tag];
    if ([request.tag isEqualToString:@"userInfoQuery"]) {
        USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialWeiboAuthError code:error.code userInfo:@{@"reason": @"Weibo request failed."}]);
    }
}
- (void)request:(WBHttpRequest *)request didFinishLoadingWithResult:(NSString *)result
{
    if ([request.tag isEqualToString:@"userInfoQuery"]) {
        NSError *decodeError;
        NSData  *data = [result dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&decodeError];
        
        NSLog(@"%@", json);
        
        ATHSocialBaseUserInfo *userInfo = [ATHSocialBaseUserInfo new];
        userInfo.nickname = json[@"name"];
        userInfo.avatarUrl = json[@"avatar_hd"];
        userInfo.uid = self.currentCredential.customInfo[@"userID"];
        userInfo.gender = ATHSocialUserGenderUnknown;
        if ([json[@"gender"] length] > 0) {
            userInfo.gender = [json[@"gender"] isEqualToString:@"m"] ? ATHSocialUserGenderMale : ATHSocialUserGenderFemale;
        }
        userInfo.signature = json[@"description"];
        
        USERINFO_COMPLETE(userInfo, nil);
    }else if ([request.tag isEqualToString:@"refreshToken"]) {
        
        NSError *decodeError;
        NSData  *data = [result dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&decodeError];
        
        ATHSocialAuthCredential *credential = [ATHSocialAuthCredential new];
        credential.platform = ATHSocialPlatformSinaWeibo;
        credential.token = json[@"access_token"];
        credential.estimatedExpireDate = [NSDate dateWithTimeIntervalSinceNow: [json[@"expires_in"] doubleValue]];
        credential.customInfo = @{
                                  @"refreshToken": json[@"refresh_token"]?:@"",
                                  @"userID": json[@"uid"]?:@""
                                  };
        
        [LOGGER log:@"SinaToken Refreshed , error :%@, new expr date: %@",decodeError, json[@"expires_in"]];
        [ATHSocialCredentialStorage storeCredential:credential]; //refresh in disk, but not in memory
    }
}

#pragma mark - WBMediaTransferProtocol

- (void)wbsdk_TransferDidReceiveObject:(id)object
{
    if (!self.pendingWeiboShareRequest) {
        return;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [WeiboSDK sendRequest:self.pendingWeiboShareRequest];
        self.pendingWeiboShareRequest = nil;
    });
}

- (void)wbsdk_TransferDidFailWithErrorCode:(WBSDKMediaTransferErrorCode)errorCode andError:(NSError *)error
{
    if (!self.pendingWeiboShareRequest) {
        return;
    }
    self.pendingWeiboShareRequest = nil;
    [LOGGER log:@"WeiboImpl transfer failed with code: %li, error: %@",errorCode, error];
    SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialWeiboShareError code:errorCode userInfo:@{@"reason": @"Share resource transfer failed."}]);
}

#pragma mark - Private

- (void)_doShareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    WBMessageObject *msgObject = [WBMessageObject message];
    msgObject.text = info.content;
    
    if (info.url.length > 0) {
        if (info.shareImages.count <= 0) {
            WBWebpageObject *webObject = [WBWebpageObject object];
            webObject.webpageUrl = info.url;
            webObject.objectID = info.url;
            webObject.title = info.title;
            webObject.description = info.subTitle;
            msgObject.mediaObject = webObject;
        }else {
            msgObject.text = [msgObject.text stringByAppendingString:[NSString stringWithFormat:@" %@",info.url]];
        }
    }
    
    if (info.shareImages.count > 0) {
        [ATHSocialWebImageManager getImagesWithArray:info.shareImages
                                           completion:^(NSArray<UIImage *> *images, NSError *error) {
                                               [self _doShareWithImages:images messageObject:msgObject];
                                           }];
    }else {
        [self _doShareWithImages:nil messageObject:msgObject];
    }

}

- (void)_doShareWithImages:(NSArray <UIImage *> *)images messageObject:(WBMessageObject *)msgObject
{
    WBImageObject *imgObject = [WBImageObject object];
    imgObject.delegate = self;
    msgObject.imageObject = imgObject;
    if (images.count > 0 && ![WeiboSDK isCanShareInWeiboAPP]) {
        //神之微博，没装客户端只能用 data 分享一张图片
        imgObject.imageData = UIImageJPEGRepresentation(images.firstObject, 0.9);
        
        [WeiboSDK sendRequest: [WBSendMessageToWeiboRequest requestWithMessage:msgObject authInfo:nil access_token:self.currentCredential.token]];
        return ;
    }
    
    //辣鸡微博不会按 images 数组顺序分享
    [imgObject addImages:images];
    // 在回调里面 sendRequest
    self.pendingWeiboShareRequest = [WBSendMessageToWeiboRequest requestWithMessage:msgObject authInfo:nil access_token:self.currentCredential.token];
}

- (void)_getUserInfo
{
    if (NEED_FETCH_USERINFO && self.currentCredential) {
        [WBHttpRequest
         requestWithURL:@"https://api.weibo.com/2/users/show.json"
         httpMethod:@"GET"
         params:@{
                  @"uid": self.currentCredential.customInfo[@"userID"],
                  @"access_token": self.currentCredential.token
                  }
         delegate:self
         withTag:@"userInfoQuery"];
    }
}

- (void)_refreshCurrentToken
{
    if (self.currentCredential && self.currentCredential.customInfo[@"refreshToken"]) {
        NSString *requestURL = [NSString stringWithFormat:@"https://api.weibo.com/oauth2/access_token?client_id=%@&client_secret=%@&grant_type=refresh_token&redirect_uri=%@&refresh_token=%@",self.appKey,self.appSecret,self.redirectUrl,self.currentCredential.customInfo[@"refreshToken"]];
        [WBHttpRequest requestWithURL:requestURL
                           httpMethod:@"POST"
                               params:@{}
                             delegate:self
                              withTag:@"refreshToken"];
    }
}


@end
