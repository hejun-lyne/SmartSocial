//
//  ATHSocialTwitterNetworkHelper.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/11.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialTwitterNetworkHelper.h"

#include <CommonCrypto/CommonDigest.h>
#include <CommonCrypto/CommonHMAC.h>

@interface ATHSocialTwitterNetworkHelper ()

//accesstoken & request
@property (nonatomic, strong) NSString *consumerKey;
@property (nonatomic, strong) NSString *consumerSecret;

@end

@implementation ATHSocialTwitterNetworkHelper

+ (instancetype)helperWithConsumerKey:(NSString *)consumerKey consumerSecret:(NSString *)secret
{
    ATHSocialTwitterNetworkHelper *helper = [ATHSocialTwitterNetworkHelper new];
    helper.consumerKey = consumerKey;
    helper.consumerSecret = secret;
    return helper;
}

- (void)apiRequestWithCommand:(NSString *)command method:(NSString *)method authParams:(NSDictionary *)authParams requestParams:(NSDictionary *)reqParam completion:(void(^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completion
{
    [self requestWithHost:@"https://api.twitter.com"
                          command:command
                           method:method
                       authParams:authParams
                    requestParams:reqParam
                     customHeader:nil
                             body:nil
                       completion:completion];
}


- (void)requestWithHost:(NSString *)host
                        command:(NSString *)command
                         method:(NSString *)method
                     authParams:(NSDictionary *)authParams
                  requestParams:(NSDictionary *)reqParam
                   customHeader:(NSDictionary *)customHeader
                           body:(NSData *)body
                     completion:(void(^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completion
{
    __block NSString *requestURL = [host stringByAppendingString:command];
    
    //encode first
    NSMutableDictionary *encodedParam = @{}.mutableCopy;
    __block NSString *query = @"";
    
    if (reqParam.count > 0) {
        
        [reqParam enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            NSString *encodedKey = [self _stringByAddingPercentEncodingForRFC3986:key];
            NSString *encodedVal = [self _stringByAddingPercentEncodingForRFC3986:obj];
            query = [query stringByAppendingString:[NSString stringWithFormat:@"%@=%@&",encodedKey,encodedVal]];
            [encodedParam setObject:encodedVal forKey:encodedKey];
        }];
        
        query = [query substringToIndex:query.length-1];
    }
    
    NSString *authString = [self _oauthHeaderWithMethod:method requestURL:requestURL customParamDict:authParams requestParamDict:encodedParam];
    
    if (![method isEqualToString:@"POST"]) {
        requestURL = [NSString stringWithFormat:@"%@?%@",requestURL,query];
    }
    NSMutableURLRequest *URLRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:requestURL]];
    if ([method isEqualToString:@"POST"]) {
        if (query.length > 0 && body.length > 0) {
            //assert
        }
        URLRequest.HTTPBody = body?:[query dataUsingEncoding:NSUTF8StringEncoding];
    }
    URLRequest.HTTPMethod = method;
    NSMutableDictionary *headerFields = [NSMutableDictionary new];
    if (customHeader) {
        [headerFields addEntriesFromDictionary:customHeader];
    }
    [headerFields addEntriesFromDictionary:@{@"Authorization": authString}];
    URLRequest.allHTTPHeaderFields = [headerFields copy];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:URLRequest completionHandler:completion] resume] ;
}


#pragma mark - Signature generation

- (NSString *)_oauthHeaderWithMethod:(NSString *)method requestURL:(NSString *)reqURLString customParamDict:(NSDictionary *)customParamDict requestParamDict:(NSDictionary *)requestParamDict
{
    NSString *consumerKey = self.consumerKey;
    NSString *consumerSecret = self.consumerSecret;
    NSString *nonce = [self _randomStringWithLength:32];
    NSString *sigMethod = @"HMAC-SHA1";
    NSString *timestamp = [NSString stringWithFormat:@"%.0lf",[[NSDate date] timeIntervalSince1970]];
    NSString *version = @"1.0";
    
    NSDictionary *paramDict = @{
                                @"oauth_consumer_key": consumerKey,
                                @"oauth_nonce": nonce,
                                @"oauth_signature_method": sigMethod,
                                @"oauth_timestamp": timestamp,
                                @"oauth_version": version
                                };
    if (customParamDict) {
        NSMutableDictionary *mdict = paramDict.mutableCopy;
        [mdict addEntriesFromDictionary:customParamDict];
        paramDict = [mdict copy];
    }
    if (requestParamDict) {
        NSMutableDictionary *mdict = paramDict.mutableCopy;
        [mdict addEntriesFromDictionary:requestParamDict];
        paramDict = [mdict copy];
    }
    NSMutableDictionary *encodedParam = @{}.mutableCopy;
    //1.Percent encode every key and value that will be signed.
    for (NSString *key in paramDict.allKeys) {
        [encodedParam setObject:[self _stringByAddingPercentEncodingForRFC3986:paramDict[key]] forKey:[self _stringByAddingPercentEncodingForRFC3986:key]];
    }
    NSArray *sortedKeys = [encodedParam.allKeys.mutableCopy sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];
    
    NSMutableArray *encodedParamArr = [NSMutableArray new];
    
    for (NSString *key in sortedKeys) {
        [encodedParamArr addObject:[NSString stringWithFormat:@"%@%@%@",key,[@"=" stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet whitespaceCharacterSet]],encodedParam[key]]];
    }
    
    NSString *paramString = [encodedParamArr componentsJoinedByString:[@"&" stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet whitespaceCharacterSet]]];
    
    NSString *urlString = [NSString stringWithFormat:@"%@&%@&%@",method,[self _stringByAddingPercentEncodingForRFC3986:reqURLString],paramString];
    
    NSString *sigKey = [[self _stringByAddingPercentEncodingForRFC3986:consumerSecret] stringByAppendingString:@"&"];
    if (self.accessTokenSecret.length > 0) {
        sigKey = [sigKey stringByAppendingString:[self _stringByAddingPercentEncodingForRFC3986:self.accessTokenSecret]];
    }
    
    NSString *signature = [self _stringByAddingPercentEncodingForRFC3986:[self _HMACSHA1WithSignKey:sigKey target:urlString]];
    
    NSDictionary *finalParamDict = @{
                                     @"oauth_consumer_key": consumerKey,
                                     @"oauth_nonce": nonce,
                                     @"oauth_signature_method": sigMethod,
                                     @"oauth_timestamp": timestamp,
                                     @"oauth_version": version,
                                     @"oauth_signature": signature
                                     };
    if (customParamDict) {
        NSMutableDictionary *mdict = finalParamDict.mutableCopy;
        [mdict addEntriesFromDictionary:customParamDict];
        finalParamDict = [mdict copy];
    }
    NSString *authString = [self _authenticationFieldFromDict:finalParamDict];
    return authString;
}


-(NSString *)_randomStringWithLength:(NSInteger)len
{
    NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString *randomString = [NSMutableString stringWithCapacity: len];
    
    for (NSInteger i = 0; i<len; i++) {
        [randomString appendFormat: @"%C", [letters characterAtIndex: arc4random_uniform((uint32_t)[letters length])]];
    }
    
    return randomString;
}


- (NSString *)_HMACSHA1WithSignKey:(NSString *)key target:(NSString *)data
{
    const char *cKey  = [key cStringUsingEncoding:NSASCIIStringEncoding];
    const char *cData = [data cStringUsingEncoding:NSASCIIStringEncoding];
    //Sha256:
    // unsigned char cHMAC[CC_SHA256_DIGEST_LENGTH];
    //CCHmac(kCCHmacAlgSHA256, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    
    //sha1
    unsigned char cHMAC[CC_SHA1_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA1, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    
    NSData *HMAC = [[NSData alloc] initWithBytes:cHMAC
                                          length:sizeof(cHMAC)];
    
    NSString *hash = [HMAC base64EncodedStringWithOptions:0];//将加密结果进行一次BASE64编码。
    return hash;
}

- (NSString *)_authenticationFieldFromDict:(NSDictionary *)dict
{
    NSMutableString *str = [@"OAuth " mutableCopy];
    [dict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        [str appendString:[NSString stringWithFormat:@"%@=%@,",key,obj]];
    }];
    return [str substringToIndex:str.length-1];
}

- (NSString *)_stringByAddingPercentEncodingForRFC3986:(NSString *)str
{
    NSString *unreserved = @"-._~";
    NSMutableCharacterSet *allowed = [NSMutableCharacterSet
                                      decimalDigitCharacterSet];
    [allowed formUnionWithCharacterSet:[NSCharacterSet letterCharacterSet]];
    [allowed addCharactersInString:unreserved];
    [allowed removeCharactersInString:@"="];
    return [str
            stringByAddingPercentEncodingWithAllowedCharacters:
            allowed];
}

@end
