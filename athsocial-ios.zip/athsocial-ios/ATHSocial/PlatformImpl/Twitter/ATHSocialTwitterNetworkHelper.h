//
//  ATHSocialTwitterNetworkHelper.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/11.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ATHSocialTwitterNetworkHelper : NSObject

@property (nonatomic, strong) NSString *accessTokenSecret;

+ (instancetype)helperWithConsumerKey:(NSString *)consumerKey consumerSecret:(NSString *)secret;

- (void)apiRequestWithCommand:(NSString *)command
                       method:(NSString *)method
                   authParams:(NSDictionary *)authParams
                requestParams:(NSDictionary *)reqParam
                   completion:(void(^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completion;


- (void)requestWithHost:(NSString *)host
                command:(NSString *)command
                 method:(NSString *)method
             authParams:(NSDictionary *)authParams
          requestParams:(NSDictionary *)reqParam
           customHeader:(NSDictionary *)customHeader
                   body:(NSData *)body
             completion:(void(^)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completion;

@end
