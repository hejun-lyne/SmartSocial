//
//  ATHSocialTwitterImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/8.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialTwitterImpl.h"
#import "ATHSocialWebViewController.h"
#import <WebKit/WKNavigationDelegate.h>
#import <WebKit/WKNavigationAction.h>

#import "ATHSocialCredentialStorage.h"
#import "ATHSocialTwitterNetworkHelper.h"
#import "ATHSocialWebImageManager.h"
#import "ATHSocialUtils.h"

static NSString * const kATHSocialTwitterShareError = @"ATHSocialTwitterShareError";
static NSString * const kATHSocialTwitterAuthError = @"ATHSocialTwitterAuthError";
static NSString * const kATHSocialTwitterUserInfoError = @"ATHSocialTwitterUserInfoError";

typedef void(^ATHTwitterUploadCompletionBlock)(NSString *mediaId, NSError *error);

@interface ATHSocialTwitterImpl ()<WKNavigationDelegate>

@property (nonatomic, copy) ATHSocialImplViewControllerGenerator vcGenerator;
@property (nonatomic, weak) UIViewController *authWebViewController;
@property (nonatomic, strong) ATHSocialTwitterNetworkHelper *networkHelper;

//accesstoken & request
@property (nonatomic, strong) NSString *consumerKey;
@property (nonatomic, strong) NSString *consumerSecret;
@property (nonatomic, strong) NSString *redirectUrl;
@property (nonatomic, strong) NSString *accessToken;
@property (nonatomic, strong) NSString *uid;
@property (nonatomic, strong) NSString *userName;
@property (nonatomic, strong) NSString *generalOAuthToken;
@property (nonatomic, strong) NSString *generalOAuthSecret;
@property (nonatomic, strong) NSString *generalOAuthVerifier;

@end

@interface ATHSocialTwitterImageHolder : NSObject
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, strong) NSString *imageUrl;
@property (nonatomic, strong) NSString *mediaId;
@end

@implementation ATHSocialTwitterImpl

- (void)config:(NSDictionary *)configDict
{
    NSString *EXTRACT_CONFIG(consumerKey);
    NSString *EXTRACT_CONFIG(consumerSecret);
    NSString *EXTRACT_CONFIG(redirectUrl);
    ATHSocialImplViewControllerGenerator EXTRACT_CONFIG(viewControllerGenerator);
    
    _consumerKey = consumerKey;
    _consumerSecret = consumerSecret;
    _redirectUrl = redirectUrl;
    _vcGenerator = [viewControllerGenerator copy];
    
}

- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError * _Nonnull))authCompletion
{
    [super requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion];
    
    ATHSocialAuthCredential *credential = [ATHSocialCredentialStorage credentialForPlatform:ATHSocialPlatformTwitter];
    
    if ([credential stillValid]) {
        [self _syncWithCredential:credential];
        AUTH_COMPLETE(credential, nil);
        return ;
    }
    
//    OAuth ：https://oauth.net/core/1.0/#anchor9
    [self.networkHelper apiRequestWithCommand:@"/oauth/request_token"
                              method:@"POST"
                              authParams:nil
                           requestParams:nil
                          completion:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                              if (error) {
                                  [LOGGER log:@"TwitterImpl error requesting token: %@",error];
                                  NSError *internalError = [NSError errorWithDomain:kATHSocialTwitterAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"error requesting request_token."}];
                                  AUTH_COMPLETE(nil, internalError);
                                  return ;
                              }
                              [self _handleRequestToken:[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]];
                          }];
    
}

- (void)shareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    [super shareWithInfo:info completion:completion];
    if (self.accessToken.length > 0) {
        [self _doShareWithInfo:info completion:completion];
    }else {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            if (error) {
                SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialTwitterShareError code:ATHSocialShareErrorCodeCancelled userInfo:@{@"reason": @"User cancel auth, leading to share failure."}]);
                return;
            }
            [self _doShareWithInfo:info completion:completion];
        }];
    }
    
}

- (void)requestUserInfoWithCompletion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    [super requestUserInfoWithCompletion:userInfoCompletion];
    if (self.accessToken.length > 0) {
        [self _getUserInfo];
    }else {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            if (error) {
                USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitterShareError code:ATHSocialShareErrorCodeCancelled userInfo:@{@"reason": @"User cancel auth, leading to user info failure."}]);
                return;
            }
            [self _getUserInfo];
        }];
    }
}

- (void)_doShareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    if (info.shareImages.count > 0) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSArray <ATHSocialTwitterImageHolder *> *imageHolders = [info.shareImages athsocial_map:^id(id obj) {
                ATHSocialTwitterImageHolder *holder = [ATHSocialTwitterImageHolder new];
                if ([obj isKindOfClass:[NSString class]]) {
                    holder.imageUrl = obj;
                }else {
                    holder.image = obj;
                }
                return holder;
            }];
            
            dispatch_group_t uploadGroup = dispatch_group_create();
            
            void (^uploadImage)(ATHSocialTwitterImageHolder *) = ^(ATHSocialTwitterImageHolder *holder){
                [self _uploadTwitterImage:holder.image format:info.preferredImageFormat completion:^(NSString *mediaId, NSError *error) {
                    if (!error && mediaId) {
                        holder.mediaId = mediaId;
                    }// 错误情况在 upload 里面有处理
                    dispatch_group_leave(uploadGroup);
                }];
            };
            for (ATHSocialTwitterImageHolder *holder in imageHolders) {
                dispatch_group_enter(uploadGroup);
                if (holder.image) {
                    uploadImage(holder);
                }else {
                    [ATHSocialWebImageManager getImageWithURL:holder.imageUrl completion:^(UIImage *image, NSError *error) {
                        if (error) {
                            dispatch_group_leave(uploadGroup);
                            [LOGGER log:@"TwitterImpl error downloading share image at [%@]",holder.imageUrl];
                            return ;
                        }
                        holder.image = image;
                        uploadImage(holder);
                    }];
                }
            }
            
            dispatch_group_notify(uploadGroup, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                [self _shareWithContent:info.content
                                    url:info.url
                               mediaIds:[imageHolders
                                         athsocial_map:^id(ATHSocialTwitterImageHolder *obj) {
                                             return obj.mediaId;
                                         }]
                 ];
            });
        });
    }else {
        [self _shareWithContent:info.content url:info.url mediaIds:nil];
    }
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    //Twitter 的授权是应用内弹窗，分享直接走请求，也没有切后台失败的场景
}

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    [super onLogoutAndRemoveAllTokens:platform];
    if ((platform & ATHSocialPlatformTwitter) == 0) {
        return ;
    }
    [self _syncWithCredential:nil];
    [ATHSocialCredentialStorage deleteCredentialForPlatform:ATHSocialPlatformTwitter];
}

#pragma mark - Handle token

- (void)_handleRequestToken:(NSString *)reqTokenResult
{
    NSDictionary *resDict = [ATHSocialUtils dictFromQuery:reqTokenResult];
    
    NSString *oauthToken = resDict[@"oauth_token"];
    NSString *oauthTokenSecret = resDict[@"oauth_token_secret"];
    BOOL cbConfirmed = [resDict[@"oauth_callback_confirmed"] boolValue];
    
    if (oauthToken.length <= 0 || oauthTokenSecret.length <= 0 || !cbConfirmed) {
        [LOGGER log:@"TwitterImpl oauth data error: %@",reqTokenResult];
        NSError *internalError = [NSError errorWithDomain:kATHSocialTwitterAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"twitter auth bad data."}];
        AUTH_COMPLETE(nil, internalError);
        return;
    }
    self.generalOAuthToken = oauthToken;
    self.generalOAuthSecret = oauthTokenSecret;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self _openTwitterAuthWebPage];
    });
}

- (void)_openTwitterAuthWebPage
{
    if (self.authWebViewController) {
        return;
    }
    ATHSocialWebViewController *webVc = [ATHSocialWebViewController new];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:webVc];
    
    NSString *authUrl = [NSString stringWithFormat:@"https://api.twitter.com/oauth/authenticate?oauth_token=%@",self.generalOAuthToken];
    webVc.webview.navigationDelegate = self;
    [webVc.webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:authUrl]]];
    webVc.title = @"Twitter";
    __weak UIViewController *weaknav = nav;
    webVc.cancelBlock = ^{
        NSError *cancelError = [NSError errorWithDomain:kATHSocialTwitterAuthError code:ATHSocialAuthErrorCodeCancelled userInfo:nil];
        
        AUTH_COMPLETE(nil, cancelError);
        [weaknav.presentingViewController dismissViewControllerAnimated:YES completion:nil];
        self.authWebViewController = nil;
    };
    self.authWebViewController = nav;
    [self.vcGenerator() presentViewController:nav animated:YES completion:nil];
    
}

- (void)_handleTokenVerifier:(NSString *)tokenResultString
{
    NSDictionary *resDict = [ATHSocialUtils dictFromQuery:tokenResultString];
    
    NSString *oauthToken = resDict[@"oauth_token"];
    NSString *oauthVerifier = resDict[@"oauth_verifier"];
    
    if (![oauthToken isEqualToString:self.generalOAuthToken] || oauthVerifier.length <= 0) {
        NSError *internalError = [NSError errorWithDomain:kATHSocialTwitterAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Twitter token verifier error."}];
        AUTH_COMPLETE(nil, internalError);
        [LOGGER log:@"TwitterImpl token verifier error: %@, current generalToken: %@",tokenResultString,self.generalOAuthToken];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.authWebViewController.presentingViewController dismissViewControllerAnimated:YES completion:nil];
            self.authWebViewController = nil;
        });
        return ;
    }
    
    self.generalOAuthVerifier = oauthVerifier;
    [self _getAccessToken];
}

- (void)_getAccessToken
{
    [self.networkHelper apiRequestWithCommand:@"/oauth/access_token"
                              method:@"POST"
                              authParams:@{
                                       @"oauth_verifier": self.generalOAuthVerifier,
                                       @"oauth_token": self.generalOAuthToken
                                       }
                       requestParams:nil
                          completion:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                              if (error) {
                                  [LOGGER log:@"TwitterImpl error requesting accesstoken: %@",error];
                                  NSError *internalError = [NSError errorWithDomain:kATHSocialTwitterAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Error requesting access_token"}];
                                  AUTH_COMPLETE(nil, internalError);
                                  return ;
                              }
                              [self _handleAccessToken:[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]];
                          }];
    
}

- (void)_handleAccessToken:(NSString *)accessTokenResult
{
    NSDictionary *resDict = [ATHSocialUtils dictFromQuery:accessTokenResult];
    
    NSString *accessToken = resDict[@"oauth_token"];
    NSString *accessTokenSecret = resDict[@"oauth_token_secret"];
    NSString *uid = resDict[@"user_id"];
    NSString *userName = resDict[@"screen_name"];
    
    if (accessToken.length <= 0 || accessTokenSecret.length <= 0 || uid.length <= 0 || userName.length <= 0) {
        [LOGGER log:@"TwitterImpl accesstoken data error: %@",accessTokenResult];
        NSError *internalError = [NSError errorWithDomain:kATHSocialTwitterAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Twitter accessToken bad data."}];
        AUTH_COMPLETE(nil, internalError);
        return ;
    }
    
    ATHSocialAuthCredential *credential = [ATHSocialAuthCredential new];
    credential.platform = ATHSocialPlatformTwitter;
    credential.token = accessToken;
    credential.estimatedExpireDate = nil;
    credential.customInfo = @{
                              kTokenSecretKey: accessTokenSecret,
                              kUserIdKey: uid,
                              @"userName": userName
                              };
    [ATHSocialCredentialStorage storeCredential:credential];
    [self _syncWithCredential:credential];
    AUTH_COMPLETE(credential, nil);
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.authWebViewController.presentingViewController dismissViewControllerAnimated:YES completion:nil];
        self.authWebViewController = nil;
    });
    [self _getUserInfo];
}

- (void)_getUserInfo
{
    if (!NEED_FETCH_USERINFO) {
        return;
    }
    [self.networkHelper apiRequestWithCommand:@"/1.1/users/show.json"
                              method:@"GET"
                          authParams:@{
                                       @"oauth_token": self.accessToken
                                       }
                       requestParams:@{
                                       @"user_id": self.uid,
                                       }
                          completion:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                              if (error) {
                                  [LOGGER log:@"TwitterImpl user info query error: %@",error];
                                  USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitterUserInfoError code:-1 userInfo:@{@"reason": @"Twitter user info query error."}]);
                                  return;
                              }
                              NSError *serializationError;
                              NSDictionary *userInfoDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&serializationError];
                              if (serializationError) {
                                  [LOGGER log:@"Twitter user info serialization error: %@", serializationError];
                                  USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitterUserInfoError code:-1 userInfo:@{@"reason": @"Twitter user info serialize error."}]);
                                  return;
                              }
                              
                              ATHSocialBaseUserInfo *info = [ATHSocialBaseUserInfo new];
                              info.uid = userInfoDict[@"id_str"];
                              info.nickname = userInfoDict[@"name"];
                              info.gender = ATHSocialUserGenderUnknown;
                              info.avatarUrl = userInfoDict[@"profile_image_url_https"];
                              info.signature = userInfoDict[@"description"];
                              
                              USERINFO_COMPLETE(info, nil);
                          }];
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    if ([navigationAction.request.URL.absoluteString containsString:self.redirectUrl]) {
        
        NSURLComponents *urlComponents = [[NSURLComponents alloc] initWithURL:navigationAction.request.URL resolvingAgainstBaseURL:YES];
        [self _handleTokenVerifier:urlComponents.query];
        
        decisionHandler(WKNavigationActionPolicyCancel);
        return ;
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}


#pragma mark - Getters

- (ATHSocialTwitterNetworkHelper *)networkHelper
{
    if (!_networkHelper) {
        _networkHelper = [ATHSocialTwitterNetworkHelper helperWithConsumerKey:self.consumerKey consumerSecret:self.consumerSecret];
    }
    return _networkHelper;
}

#pragma mark - Helpers

- (void)_syncWithCredential:(ATHSocialAuthCredential *)credential
{
    self.accessToken = credential.token;
    self.networkHelper.accessTokenSecret = credential.customInfo[kTokenSecretKey];
    self.uid = credential.customInfo[kUserIdKey];
    self.userName = credential.customInfo[@"userName"];
}

#pragma mark - Share

- (void)_shareWithContent:(NSString *)content url:(NSString *)URLString mediaIds:(NSArray *)mediaIds
{
    NSMutableDictionary *param = @{@"status": [NSString stringWithFormat:@"%@ %@",content,URLString]}.mutableCopy;
    if (mediaIds.count > 0) {
        [param setObject:[mediaIds componentsJoinedByString:@","] forKey:@"media_ids"];
    }
    // test
    NSString *testImageUrl = @"https://images-na.ssl-images-amazon.com/images/G/01/dvd/warner/darkknight1lg.jpg";
    NSInteger testId = 861612212244162561;
    NSData *testData = [NSJSONSerialization dataWithJSONObject:@{
                                                                 @"media":@[
                                                                         @{
                                                                             @"id": @(testId),
                                                                             @"id_str": [NSString stringWithFormat:@"%li",testId],
                                                                             @"type": @"photo",
                                                                             @"media_url_https": testImageUrl,
                                                                             @"media_url": [testImageUrl stringByReplacingOccurrencesOfString:@"https" withString:@"http"],
                                                                             @"indices": @[@0,@(testImageUrl.length)],
                                                                             @"url": testImageUrl
                                                                             }
                                                                         ]
                                                                 } options:NSJSONWritingPrettyPrinted error:nil];
    [param setObject:[[NSString alloc] initWithData:testData encoding:NSUTF8StringEncoding]
              forKey:@"entities"];
    
    [self.networkHelper apiRequestWithCommand:@"/1.1/statuses/update.json"
                              method:@"POST"
                          authParams:@{@"oauth_token": self.accessToken}
                       requestParams:param.copy
                          completion:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                              if (error) {
                                  [LOGGER log:@"TwitterImpl request update.json error: %@, content [%@], url [%@], medias [%@]",error, content, URLString, mediaIds];
                                  SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialTwitterShareError code:ATHSocialShareErrorCodeSDKError userInfo:@{@"reason": @"Error posting new tweet."}]);
                                  return ;
                              }
                              SHARE_COMPLETE(YES, nil);
                          }];
}


// simple image upload
- (void)_uploadTwitterImage:(UIImage *)image format:(ATHShareImageFormat)format completion:(ATHTwitterUploadCompletionBlock)completion
{
    NSString *boundary = @"Boundary-ath";
    NSData *imageData = format == ATHShareImageFormatPNG ? UIImagePNGRepresentation(image) : UIImageJPEGRepresentation(image, 1.0);
    NSString *contentType = format == ATHShareImageFormatPNG ? @"Content-Type: image/png" : @"Content-Type: image/jpeg";
    
    NSMutableData *requestData = [NSMutableData new];
    NSString *pair = [NSString stringWithFormat:@"--%@\r\nContent-Disposition: form-data; name=\"%@\"\r\n\r\n",boundary,@"media"];
    [requestData appendData:[pair dataUsingEncoding:NSUTF8StringEncoding]];
    [requestData appendData:imageData];
    [requestData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [requestData appendData:[contentType dataUsingEncoding:NSUTF8StringEncoding]];
    [requestData appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    [self.networkHelper requestWithHost:@"https://upload.twitter.com"
                          command:@"/1.1/media/upload.json"
                           method:@"POST"
                       authParams:@{@"oauth_token": self.accessToken}
                    requestParams:nil
                     customHeader:@{@"Content-Type": [NSString stringWithFormat:@"multipart/form-data;boundary=%@",boundary]}
                             body:requestData
                       completion:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                           if (error) {
                               [LOGGER log:@"TwitterImpl upload image error, uploadError: %@", error];
                               completion(nil, error);
                               return ;
                           }
                           
                           NSError *serializationError;
                           NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&serializationError];
                           if (!serializationError && dict[@"media_id_string"]) {
                               completion(dict[@"media_id_string"], nil);
                           }else{
                               [LOGGER log:@"TwitterImpl upload image error, serializationError: %@, dict: %@", serializationError, dict];
                               completion(nil, serializationError?:[NSError errorWithDomain:kATHSocialTwitterAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:nil]);
                           }
                       }];
}

//Risk: twitter supports chunk upload. might be good to implement it in the furture.

@end

@implementation ATHSocialTwitterImageHolder

@end
