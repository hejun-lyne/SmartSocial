//
//  ATHSocialTwitchImpl.h
//  ATHSocial
//
//  Created by Gocy on 2018/7/14.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialBaseImpl.h"

NS_ASSUME_NONNULL_BEGIN

@interface ATHSocialTwitchImpl : ATHSocialBaseImpl

@end

NS_ASSUME_NONNULL_END
