//
//  ATHSocialTwitchImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/7/14.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialTwitchImpl.h"
#import "ATHSocialWebViewController.h"

#import <WebKit/WKNavigationDelegate.h>
#import <WebKit/WKNavigationAction.h>

#import "ATHSocialUtils.h"
#import "ATHSocialCredentialStorage.h"

static NSString * const kATHSocialTwitchAuthError = @"ATHSocialTwitchAuthError";
static NSString * const kATHSocialTwitchShareError = @"ATHSocialTwitchShareError";
static NSString * const kATHSocialTwitchUserInfoError = @"ATHSocialTwitchUserInfoError";

static NSString * const kTwitchRefreshTokenKey = @"com.athsocial.twitch";

@interface ATHSocialTwitchImpl () <WKNavigationDelegate>

@property (nonatomic, copy) ATHSocialImplViewControllerGenerator vcGenerator;
@property (nonatomic, strong) NSString *redirectUrl;
@property (nonatomic, strong) NSString *clientId;
@property (nonatomic, strong) NSString *secret;
@property (nonatomic, strong) NSArray *scopes;
@property (nonatomic, weak) UIViewController *authWebViewController;

@property (nonatomic, strong) ATHSocialAuthCredential *credential;

@end

@implementation ATHSocialTwitchImpl

- (void)config:(NSDictionary *)configDict
{
    
    NSString *EXTRACT_CONFIG(clientId);
    NSString *EXTRACT_CONFIG(redirectUrl);
    NSString *EXTRACT_CONFIG(secret);
    ATHSocialImplViewControllerGenerator EXTRACT_CONFIG(viewControllerGenerator);
    
    _clientId = clientId;
    _redirectUrl = redirectUrl;
    _secret = secret;
    _vcGenerator = [viewControllerGenerator copy];
    self.scopes = @[@"user:edit", @"chat_login", @"user_read"];
}


- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError * _Nonnull))authCompletion
{
    [super requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion];
    
    [self _doAuth];
}

- (void)requestUserInfoWithCompletion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    [super requestUserInfoWithCompletion:userInfoCompletion];
    if ([self.credential stillValid]) {
        [self _getUserInfo];
    }else {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            if (!error) {
                [self _getUserInfo];
            }
        }];
    }
}

- (void)shareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError * _Nonnull))completion
{
    [super shareWithInfo:info completion:completion];
}

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    [super onLogoutAndRemoveAllTokens:platform];
    if ((platform & ATHSocialPlatformTwitch) == 0) {
        return ;
    }
    [LOGGER log:@"Twitch cleanning everything."];
    self.credential = nil;
    [ATHSocialCredentialStorage deleteCredentialForPlatform:ATHSocialPlatformTwitch];
}


#pragma mark - OAuth

- (void)_doAuth
{
    if (!self.credential) {
        self.credential = [ATHSocialCredentialStorage credentialForPlatform:ATHSocialPlatformTwitch];
    }
    
    if (self.credential) {
        if ([self.credential stillValid]) {
            AUTH_COMPLETE(self.credential, nil);
            [self _refreshCredentialWithCompletion:^(BOOL success, ATHSocialAuthCredential *cred) {
                if (success && cred) {
                    self.credential = cred;
                    [ATHSocialCredentialStorage storeCredential:cred];
                }
            }];
        } else {
            [self _refreshCredentialWithCompletion:^(BOOL success, ATHSocialAuthCredential *cred) {
                if (success && cred) {
                    self.credential = cred;
                    [ATHSocialCredentialStorage storeCredential:cred];
                    AUTH_COMPLETE(self.credential, nil);
                }else {
                    AUTH_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitchAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:nil]);
                }
            }];
        }
    }else {
        [self _openAuthWebPage];
    }
}

- (void)_openAuthWebPage
{
    ATHSocialWebViewController *webVc = [ATHSocialWebViewController new];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:webVc];
    
    NSString *encodedRedirectUrl = [self.redirectUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet alphanumericCharacterSet]];
    NSString *authUrl = [NSString stringWithFormat:@"https://id.twitch.tv/oauth2/authorize?client_id=%@&redirect_uri=%@&response_type=code&scope=%@&state=%@",
                         self.clientId,
                         encodedRedirectUrl,
                         [self.scopes componentsJoinedByString:@"+" ],
                         [[NSUUID UUID] UUIDString]];
    
    webVc.webview.navigationDelegate = self;
    [webVc.webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:authUrl]]];
    webVc.title = @"Twitch";
    __weak UIViewController *weaknav = nav;
    webVc.cancelBlock = ^{
        NSError *cancelError = [NSError errorWithDomain:kATHSocialTwitchAuthError code:ATHSocialAuthErrorCodeCancelled userInfo:nil];
        
        AUTH_COMPLETE(nil, cancelError);
        [weaknav.presentingViewController dismissViewControllerAnimated:YES completion:nil];
        self.authWebViewController = nil;
    };
    self.authWebViewController = nav;
    [self.vcGenerator() presentViewController:nav animated:YES completion:nil];
}

- (void)_refreshCredentialWithCompletion:(void(^)(BOOL success, ATHSocialAuthCredential *cred))completion
{
    if (!completion) {
        return ;
    }
    if (!self.credential) {
        completion(NO, nil);
        return ;
    }
    
    [LOGGER log:@"TwitchImpl, updating access token."];
    
    NSString *refreshToken = self.credential.customInfo[kTwitchRefreshTokenKey];
    
    NSString *encodedRefreshToken = [refreshToken stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet alphanumericCharacterSet]];
    
    NSString *reqUrl = [NSString stringWithFormat:@"https://id.twitch.tv/oauth2/token?grant_type=refresh_token&refresh_token=%@&client_id=%@&client_secret=%@",
                        encodedRefreshToken,
                        self.clientId,
                        self.secret];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:reqUrl]];
    req.HTTPMethod = @"POST";
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (data && !error) {
            NSError *serializationError;
            NSDictionary *resultDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&serializationError];
            if (serializationError == nil) {
                NSString *accessToken = resultDict[@"access_token"];
                NSString *refreshToken = resultDict[@"refresh_token"];
                NSInteger expiresIn = [resultDict[@"expires_in"] integerValue];
                
                if (accessToken.length <= 0 || refreshToken.length <= 0) {
                    [LOGGER log:@"TwitchImpl, Token refresh data invalid: %@",resultDict];
                    completion(NO, nil);
                    return ;
                }
                
                ATHSocialAuthCredential *cred = [ATHSocialAuthCredential new];
                cred.token = accessToken;
                cred.estimatedExpireDate = [[NSDate date] dateByAddingTimeInterval:(NSTimeInterval)expiresIn];
                cred.customInfo = @{
                                    kTwitchRefreshTokenKey: refreshToken
                                    };
                cred.platform = ATHSocialPlatformTwitch;
                
                completion(YES, cred);
            }else {
                [LOGGER log:@"TwitchImpl, token refresh serialization error : %@",serializationError];
                completion(NO, nil);
            }

            
        }else {
            [LOGGER log:@"TwitchImpl, Token Refresh failed : %@",error];
            completion(NO, nil);
        }
    }] resume];
}

- (void)_handleAccessCode:(NSString *)codeResultString
{
    NSDictionary *dict = [ATHSocialUtils dictFromQuery:codeResultString];
    NSString *accessCode = dict[@"code"];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.authWebViewController.presentingViewController dismissViewControllerAnimated:YES completion:nil];
    });
    if (!accessCode) {
        NSError *error = [NSError errorWithDomain:kATHSocialTwitchAuthError code:ATHSocialAuthErrorCodeCancelled userInfo:nil];
        AUTH_COMPLETE(nil, error);
        [LOGGER log:@"TwitchImpl access code invalid: %@", codeResultString];
        return ;
    }
    
    [LOGGER log:@"Did get access code, retriving access token."];
    
    [self _getAccessTokenWithCode:accessCode];
}

- (void)_getAccessTokenWithCode:(NSString *)code
{
    
    NSString *encodedRedirectUrl = [self.redirectUrl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet alphanumericCharacterSet]];

    NSString *reqUrl = [NSString stringWithFormat:@"https://id.twitch.tv/oauth2/token?client_id=%@&client_secret=%@&code=%@&grant_type=authorization_code&redirect_uri=%@",
                        self.clientId,
                        self.secret,
                        code,
                        encodedRedirectUrl];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:reqUrl]];
    req.HTTPMethod = @"POST";
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (data && !error) {
            NSError *serializationError;
            NSDictionary *resultDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&serializationError];
            if (serializationError == nil) {
                NSString *accessToken = resultDict[@"access_token"];
                NSString *refreshToken = resultDict[@"refresh_token"];
                NSInteger expiresIn = [resultDict[@"expires_in"] integerValue];
                
                if (accessToken.length <= 0 || refreshToken.length <= 0 || expiresIn <= 0) {
                    [LOGGER log:@"TwitchImpl, access token dict invalid : %@",resultDict];
                    AUTH_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitchAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:nil]);
                }
                
                self.credential = [ATHSocialAuthCredential new];
                self.credential.token = accessToken;
                self.credential.estimatedExpireDate = [[NSDate date] dateByAddingTimeInterval:(NSTimeInterval)expiresIn];
                self.credential.customInfo = @{
                                               kTwitchRefreshTokenKey: refreshToken
                                               };
                self.credential.platform = ATHSocialPlatformTwitch;
                [ATHSocialCredentialStorage storeCredential:self.credential];
                
                AUTH_COMPLETE(self.credential, nil);
            }else {
                [LOGGER log:@"TwitchImpl, access token serialization error : %@",serializationError];
                
                AUTH_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitchAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:nil]);
            }

        }else {
            [LOGGER log:@"TwitchImpl, access token req failed : %@",error];
            AUTH_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitchAuthError code:ATHSocialAuthErrorCodeSDKError userInfo:nil]);
        }
    }] resume] ;
}

#pragma mark - User Info

- (void)_getUserInfo
{
    NSString *reqUrl = @"https://api.twitch.tv/kraken/user";
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:reqUrl]];
    
    NSMutableDictionary *dict = req.allHTTPHeaderFields ? req.allHTTPHeaderFields.mutableCopy : @{}.mutableCopy;
    [dict setObject:self.clientId ? : @"" forKey:@"Client-ID"];
    [dict setObject:[NSString stringWithFormat:@"OAuth %@",self.credential.token] forKey:@"Authorization"];
    [dict setObject:@"application/vnd.twitchtv.v5+json" forKey:@"Accept"];
    
    req.allHTTPHeaderFields = [dict copy];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (data && !error) {
            NSError *serializationError;
            NSDictionary *resultDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&serializationError];
            if (serializationError == nil) {
                NSLog(@"%@",resultDict);
                ATHSocialBaseUserInfo *userInfo = [ATHSocialBaseUserInfo new];
                userInfo.nickname = resultDict[@"display_name"] ? : resultDict[@"name"];
                userInfo.uid = [NSString stringWithFormat:@"%li",[resultDict[@"_id"] integerValue]];
                userInfo.gender = ATHSocialUserGenderUnknown;
                userInfo.avatarUrl = resultDict[@"logo"];
                userInfo.signature = resultDict[@"bio"];
                
                USERINFO_COMPLETE(userInfo, nil);
            }else {
                [LOGGER log:@"TwitchImpl, User info serialization error : %@",serializationError];
                
                USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitchUserInfoError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Twitch get user info data invalid."}]);
            }
        }else {
            [LOGGER log:@"TwitchImpl, req user info error : %@", error];
            USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialTwitchUserInfoError code:ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Twitch get user info request failed."}]);
        }
    }] resume];
    
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    if ([navigationAction.request.URL.absoluteString hasPrefix:self.redirectUrl]) {
        
        NSURLComponents *urlComponents = [[NSURLComponents alloc] initWithURL:navigationAction.request.URL resolvingAgainstBaseURL:YES];
        [self _handleAccessCode:urlComponents.fragment?:urlComponents.query];
        
        decisionHandler(WKNavigationActionPolicyCancel);
        return ;
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    NSLog(@"webview did finish loading URL %@", webView.URL.absoluteString);
}

@end
