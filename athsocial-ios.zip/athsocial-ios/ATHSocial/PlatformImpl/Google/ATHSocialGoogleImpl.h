//
//  ATHSocialGoogleImpl.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialBaseImpl.h"

//NS_ASSUME_NONNULL_BEGIN

@interface ATHSocialGoogleImpl : ATHSocialBaseImpl

@end

//NS_ASSUME_NONNULL_END
