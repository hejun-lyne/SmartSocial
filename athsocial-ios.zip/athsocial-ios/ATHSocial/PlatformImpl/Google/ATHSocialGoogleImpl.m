//
//  ATHSocialGoogleImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialGoogleImpl.h"
#import <GoogleSignIn/GoogleSignIn.h>

static NSString * const kATHSocialGoogleAuthError = @"ATHSocialGoogleAuthError";

@interface ATHSocialGoogleImpl () <GIDSignInDelegate, GIDSignInUIDelegate>

@property (nonatomic, copy) ATHSocialImplViewControllerGenerator vcGenerator;
@property (nonatomic, strong) NSString *clientId;
@property (nonatomic, assign) BOOL signInSiliently;

@end

@implementation ATHSocialGoogleImpl

- (void)config:(NSDictionary *)configDict
{
    NSString *EXTRACT_CONFIG(clientId);
    ATHSocialImplViewControllerGenerator EXTRACT_CONFIG(viewControllerGenerator);
    
    _clientId = clientId;
    _vcGenerator = [viewControllerGenerator copy];
}

- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError * _Nonnull))authCompletion
{
    [super requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion];
    BOOL hasPreviousAuth = [[self gidSignIn] hasAuthInKeychain];
    if (hasPreviousAuth) {
        // 谷歌自己有存储策略，不用自己的存储方案
        self.signInSiliently = YES;
        [[self gidSignIn] signInSilently];
        [LOGGER log:@"GoogleAuth signning in siliently"];
    }else{
        self.signInSiliently = NO;
        [[self gidSignIn] signIn];
        [LOGGER log:@"GoogleAuth signning in"];
    }
}

- (void)requestUserInfoWithCompletion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    void (^callback)(GIDGoogleUser *) = ^(GIDGoogleUser *user){
        ATHSocialBaseUserInfo *userInfo = [ATHSocialBaseUserInfo new];
        userInfo.nickname = user.profile.name;
        userInfo.avatarUrl = [[user.profile imageURLWithDimension:256] absoluteString];
        userInfo.uid = user.userID;
        userInfo.gender = ATHSocialUserGenderUnknown;
        userInfo.signature = @"";
        USERINFO_COMPLETE(userInfo, nil);
    };
    [super requestUserInfoWithCompletion:userInfoCompletion];
    if ([[self gidSignIn] currentUser]) {
        callback([[self gidSignIn] currentUser]);
    }else {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            if (error) {
                USERINFO_COMPLETE(nil, error);
                return ;
            }
            callback([[self gidSignIn] currentUser]);
        }];
    }
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation
{
    BOOL handled = [[self gidSignIn] handleURL:url sourceApplication:sourceApp annotation:annotation];
    [LOGGER log:@"GoogleImpl handle url: %@, res: %i",url.absoluteString,handled];
    return handled;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability"
    BOOL handled = [[self gidSignIn]
            handleURL:url
            sourceApplication:options[UIApplicationOpenURLOptionsSourceApplicationKey]
            annotation:options[UIApplicationOpenURLOptionsAnnotationKey]];
#pragma clang diagnostic pop
    [LOGGER log:@"GoogleImpl handle url: %@, res: %i",url.absoluteString,handled];
    
    return handled;
}

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    [super onLogoutAndRemoveAllTokens:platform];
    if ((platform & ATHSocialPlatformGoogle) == 0) {
        return ;
    }
    [LOGGER log:@"GoogleAuth cleanning everything."];
    [[self gidSignIn] signOut];
}

#pragma mark - Getter

- (GIDSignIn *)gidSignIn
{
    static dispatch_once_t onceToken; // 希望可以懒加载
    dispatch_once(&onceToken, ^{
        [GIDSignIn sharedInstance].clientID = self.clientId;
        [GIDSignIn sharedInstance].delegate = self;
        [GIDSignIn sharedInstance].uiDelegate = self;
        [GIDSignIn sharedInstance].shouldFetchBasicProfile = YES;
    });
    return [GIDSignIn sharedInstance];
}


#pragma mark - GIDSignInDelegate

- (void)signIn:(GIDSignIn *)signIn didSignInForUser:(GIDGoogleUser *)user withError:(NSError *)error
{
    if (error) {
        [LOGGER log:@"GoogleAuth signin with error: %@",error];
        if (self.signInSiliently && error.code == kGIDSignInErrorCodeHasNoAuthInKeychain) { // keychain 里面有 auth 导致调了 signInSliently，但是如果还是报了没 keychain，转为普通 signIn
            self.signInSiliently = NO;
            [[self gidSignIn] signIn];
            return ;
        }
        NSError *signInError = [NSError errorWithDomain:kATHSocialGoogleAuthError code:error.code == kGIDSignInErrorCodeCanceled ? ATHSocialAuthErrorCodeCancelled : ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Google auth failed."}];
        AUTH_COMPLETE(nil, signInError);
        return ;
    }
    ATHSocialAuthCredential *credential = [self _credentialFromGoogleAuth:user.authentication];
    AUTH_COMPLETE(credential, nil);
    [LOGGER log:@"GoogleAuth signin success, credential expr date: %@",credential.estimatedExpireDate];
    
}

- (void)signIn:(GIDSignIn *)signIn didDisconnectWithUser:(GIDGoogleUser *)user withError:(NSError *)error
{
    [LOGGER log:@"GoogleAuth disconnected"];
}

#pragma mark - GIDSignInUIDelegate

- (void)signInWillDispatch:(GIDSignIn *)signIn error:(NSError *)error
{
}

- (void)signIn:(GIDSignIn *)signIn presentViewController:(UIViewController *)viewController
{
    NSAssert(self.vcGenerator != nil, @"Google Impl must have a vc generate");
    UIViewController *vc = self.vcGenerator();
    NSAssert(vc != nil, @"Google Impl getting a nil view controller");
    
    [vc presentViewController:viewController animated:YES completion:nil];
}

- (void)signIn:(GIDSignIn *)signIn dismissViewController:(UIViewController *)viewController
{
    [viewController.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - helpers
- (ATHSocialAuthCredential *)_credentialFromGoogleAuth:(GIDAuthentication *)authentication
{
    
    ATHSocialAuthCredential *credential = [ATHSocialAuthCredential new];
    credential.platform = ATHSocialPlatformGoogle;
    credential.estimatedExpireDate = authentication.accessTokenExpirationDate;
    credential.token = authentication.accessToken;
    
    credential.customInfo = @{
                                @"googleAuth": authentication
                            };
    
    return credential;
}

@end
