//
//  ATHSocialWechatImpl.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ATHSocialBaseImpl.h"

//NS_ASSUME_NONNULL_BEGIN

@interface ATHSocialWechatImpl : ATHSocialBaseImpl

- (void)shareWithInfo:(id<IATHShareInfo>)info channel:(ATHShareChannel)channel completion:(void (^)(BOOL, NSError * _Nonnull))completion;


@end

//NS_ASSUME_NONNULL_END
