//
//  ATHSocialWechatImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/6.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialWechatImpl.h"
#import "WXApi.h"
#import "WXApiObject.h"

@interface ATHSocialWechatImpl () <WXApiDelegate>


@end

@implementation ATHSocialWechatImpl

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation
{
    BOOL handled = [WXApi handleOpenURL:url delegate:self];
    [LOGGER log:@"WechatImpl handle url: %@, res: %i",url.absoluteString,handled];
    return handled;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    BOOL handled = [WXApi handleOpenURL:url delegate:self];
    [LOGGER log:@"WechatImpl handle url: %@, res: %i",url.absoluteString,handled];
    return [WXApi handleOpenURL:url delegate:self];
}

- (void)shareWithInfo:(id<IATHShareInfo>)info channel:(ATHShareChannel)channel completion:(void (^)(BOOL, NSError * _Nonnull))completion
{
    
    SendMessageToWXReq *req = [SendMessageToWXReq new];
    WXMediaMessage *mediaMsg = [WXMediaMessage message];
    mediaMsg.title = info.title;
    mediaMsg.description = info.subTitle;
    
    if (info.shareImages.count > 0) {
        WXImageObject *imgObject = [WXImageObject object];
        imgObject.imageData = info.preferredImageFormat == ATHShareImageFormatPNG ? UIImagePNGRepresentation(info.shareImages.firstObject) : UIImageJPEGRepresentation(info.shareImages.firstObject, 1.0);
        mediaMsg.mediaObject = imgObject;
    }else if (info.url.length > 0) {
        WXWebpageObject *webObject = [WXWebpageObject object];
        webObject.webpageUrl = info.url;
        mediaMsg.mediaObject = webObject;
    }
    
    req.message = mediaMsg;
    req.text = info.content;
    
    if (channel == ATHShareChannelWechatFriend) {
        req.scene = WXSceneSession;
    }else if (channel == ATHShareChannelWechatMoments){
        req.scene = WXSceneTimeline;
    }
    
    [WXApi sendReq:req];
}

- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError * _Nonnull))authCompletion *))userInfoCompletion
{
    [super requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion]];
}

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    [super onLogoutAndRemoveAllTokens:platform];
}

#pragma mark - WXApiDelegate

- (void)onReq:(BaseReq *)req
{
    
}

- (void)onResp:(BaseResp *)resp
{
    NSLog(@"%@", resp);
}

@end
