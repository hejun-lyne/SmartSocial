//
//  ATHSocialFacebookImpl.m
//  ATHSocial
//
//  Created by Gocy on 2018/6/7.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialFacebookImpl.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginManager.h>
#import <FBSDKLoginKit/FBSDKLoginManagerLoginResult.h>

#import <FBSDKShareKit/FBSDKShareKit.h>

#import "ATHSocialWebImageManager.h"
#import "ATHSocialCredentialStorage.h"

static NSString * const kSocialFBGrantedPermissionsKey = @"com.athsocial.fb.grantedPermissions";
static NSString * const kSocialFBDeclinedPermissionsKey = @"com.athsocial.fb.declinedPermission";
static NSString * const kSocialFBAppIdKey = @"com.athsocial.fb.appID";
static NSString * const kSocialFBUserIdKey = @"com.athsocial.fb.userID";
static NSString * const kSocialFBTokenRefreshDateKey = @"com.athsocial.fb.tokenRefreshDate";

static NSString * const kATHSocialFacebookShareError = @"ATHSocialFacebookShareError";
static NSString * const kATHSocialFacebookAuthError = @"ATHSocialFacebookAuthError";
static NSString * const kATHSocialFacebookProfileError = @"ATHSocialFacebookProfileError";

@interface ATHSocialFacebookImpl ()<FBSDKSharingDelegate>

@property (nonatomic, weak) UIApplication *application;
@property (nonatomic, strong) NSDictionary *launchOptions;
@property (nonatomic, strong) FBSDKLoginManager *fblogin;

@property (nonatomic, copy) ATHSocialImplViewControllerGenerator vcGenerator;

@property (nonatomic, weak) FBSDKShareDialog *currentDialog;

@end

@implementation ATHSocialFacebookImpl


//TODO: 监听通知，判断用户账号https://developers.facebook.com/docs/facebook-login/ios/advanced  访问口令（通知） ? 感觉其实不用
- (void)config:(NSDictionary *)configDict
{
    UIApplication *EXTRACT_CONFIG(application);
    NSDictionary *EXTRACT_CONFIG(launchOptions);
    ATHSocialImplViewControllerGenerator EXTRACT_CONFIG(viewControllerGenerator);
    
    _application = application;
    _launchOptions = launchOptions;
    _vcGenerator = [viewControllerGenerator copy];
}

- (void)requestAuthWithExtendInfo:(NSDictionary *)extendInfo authCompletion:(void (^)(ATHSocialAuthCredential *, NSError *))authCompletion
{
    [super requestAuthWithExtendInfo:extendInfo authCompletion:authCompletion];
    
    NSString *publicProfilePermission = @"public_profile";
    
    ATHSocialAuthCredential *credential = [ATHSocialCredentialStorage credentialForPlatform:ATHSocialPlatformFacebook];
    if ([credential stillValid] && [credential.customInfo[kSocialFBGrantedPermissionsKey] containsObject: publicProfilePermission]) {
        [LOGGER log:@"FacebookAuth using cached credential, expr date: %@",credential.estimatedExpireDate];
        AUTH_COMPLETE(credential, nil);
        [self _setupFacebookWithCredential:credential completion:nil];
        return;
    }
    
    // facebooksdk 已经默认不调起 app 了https://www.jianshu.com/p/c3b4c7027fa4
    [self.fblogin logInWithReadPermissions:@[publicProfilePermission]
                        fromViewController:self.vcGenerator()
                                   handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
                                       if (error || result.isCancelled) {
                                           [LOGGER log:@"Facebook auth error: %@, result.isCancelled: %i",error,result.isCancelled];
                                           NSError *authError = [NSError errorWithDomain:kATHSocialFacebookAuthError code:result.isCancelled ? ATHSocialAuthErrorCodeCancelled : ATHSocialAuthErrorCodeSDKError userInfo:@{@"reason": @"Facebook auth failed."}];
                                           AUTH_COMPLETE(nil, authError);
                                           return ;
                                       }
                                       ATHSocialAuthCredential *credential = [self _credentialFromToken:result.token grantedPermissions:[result.grantedPermissions allObjects] declinedPermissions:[result.declinedPermissions allObjects]];
                                       
                                       [ATHSocialCredentialStorage storeCredential:credential];
                                       
                                       AUTH_COMPLETE(credential, nil);
                                       [LOGGER log:@"FacebookAuth with error %@, expr date: %@",error,credential.estimatedExpireDate];
                                       
                                   }];
}

- (void)shareWithInfo:(id<IATHShareInfo>)info completion:(void (^)(BOOL, NSError *))completion
{
    [super shareWithInfo:info completion:completion];
    
    if (info.shareImages.count > 0) {
        [ATHSocialWebImageManager getImagesWithArray:info.shareImages completion:^(NSArray<UIImage *> *images, NSError *error) {
            FBSDKSharePhotoContent *photoContent = [FBSDKSharePhotoContent new];
            FBSDKShareMediaContent *mediaContent = [FBSDKShareMediaContent new];
            NSArray *fbPhotos = [images athsocial_map:^id(UIImage *obj) {
                return [FBSDKSharePhoto photoWithImage:obj userGenerated:YES];
            }];
            mediaContent.media = fbPhotos;
            photoContent.photos = fbPhotos;
            
            [self _checkPublishPermissionThen:^(BOOL granted) {
                if (!granted) {
                    SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialFacebookShareError code:ATHSocialShareErrorCodeSDKError userInfo:@{@"reason": @"Publish permission declined."}]);
                    return ;
                }
                dispatch_async(dispatch_get_main_queue(), ^{
                    FBSDKShareDialog *dialog = [[FBSDKShareDialog alloc] init];
                    dialog.fromViewController = self.vcGenerator();
                    dialog.mode = FBSDKShareDialogModeNative;
                    dialog.shareContent = photoContent;
                    dialog.delegate = self;
                    [dialog show];
                    self.currentDialog = dialog;
                });
            }];
        }];
    }else if (info.url.length > 0) {
        FBSDKShareLinkContent *linkContent = [FBSDKShareLinkContent new];
        linkContent.contentURL = [NSURL URLWithString: info.url];
        linkContent.quote = info.content;
        
        [self _checkPublishPermissionThen:^(BOOL granted) {
            if (!granted) {
                SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialFacebookShareError code:ATHSocialShareErrorCodeSDKError userInfo:@{@"reason": @"Publish permission declined."}]);
                return ;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                self.currentDialog = [FBSDKShareDialog showFromViewController:self.vcGenerator() withContent:linkContent delegate:self];
            });
        }];
    }
}

- (void)requestUserInfoWithCompletion:(void (^)(ATHSocialBaseUserInfo *, NSError *))userInfoCompletion
{
    [super requestUserInfoWithCompletion:userInfoCompletion];
    NSString *publicProfilePermission = @"public_profile";
    if ([[[FBSDKAccessToken currentAccessToken] permissions] containsObject:publicProfilePermission]) {
        [self _getUserInfo];
    }else {
        [self requestAuthWithExtendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
            if (error) {
                USERINFO_COMPLETE(nil, error);
                return ;
            }
            [self _getUserInfo];
        }];
    }
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url sourceApplication:(NSString *)sourceApp annotation:(id)annotation
{
    BOOL handled = [[self fbapp] application:application openURL:url sourceApplication:sourceApp annotation:annotation];
    [LOGGER log:@"FacebookImpl handle url(sourceapp): %@, res: %i",url.absoluteString,handled];
    return handled;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
    BOOL handled = [[self fbapp] application:app openURL:url options:options];
    [LOGGER log:@"FacebookImpl handle url(options): %@, res: %i",url.absoluteString,handled];
    return handled;
}


- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Risk: 这种判断是不是正确？
    if (self.currentDialog) {
        if (self.currentDialog.fromViewController.presentedViewController) {
            NSString *vcClass = NSStringFromClass(self.currentDialog.fromViewController.presentedViewController.class);
            if ([vcClass hasPrefix:@"FBSDK"]) { // 当前 dialog present 了一个 FB 的 webvc，不算失败。
                return ;
            }
        }
        SHARE_COMPLETE(NO, [NSError errorWithDomain:kATHSocialFacebookShareError code:ATHSocialShareErrorCodeCancelled userInfo:@{@"reason": @"openURL not called, but app become active again, means that user did not come straightly back to the app."}]);
    }
    
}

- (void)onLogoutAndRemoveAllTokens:(ATHSocialPlatform)platform
{
    if ((platform & ATHSocialPlatformFacebook) == 0) {
        return ;
    }
    [ATHSocialCredentialStorage deleteCredentialForPlatform:ATHSocialPlatformFacebook];
    [[self fblogin] logOut];
}

#pragma mark - Helpers

- (void)_setupFacebookWithCredential:(ATHSocialAuthCredential *)credential completion:(void(^)(void))completion
{
    NSDictionary *info = credential.customInfo;
    FBSDKAccessToken *fbtoken = [[FBSDKAccessToken alloc] initWithTokenString:credential.token permissions:info[kSocialFBGrantedPermissionsKey] declinedPermissions:info[kSocialFBDeclinedPermissionsKey] appID:info[kSocialFBAppIdKey] userID:info[kSocialFBUserIdKey] expirationDate:credential.estimatedExpireDate refreshDate:info[kSocialFBTokenRefreshDateKey]];
    [FBSDKAccessToken setCurrentAccessToken:fbtoken];
    [FBSDKAccessToken refreshCurrentAccessToken:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
        if (error) {
            [LOGGER log:@"FacebookImpl refresh token error: %@",error];
            return ;
        }
        FBSDKAccessToken *token = [FBSDKAccessToken currentAccessToken];
        
        ATHSocialAuthCredential *refreshedCredential = [self _credentialFromToken:token grantedPermissions:info[kSocialFBGrantedPermissionsKey] declinedPermissions:info[kSocialFBDeclinedPermissionsKey]];
        
        [ATHSocialCredentialStorage storeCredential:refreshedCredential];
        [LOGGER log:@"FacebookAuth cached credential refreshed, expr date: %@",refreshedCredential.estimatedExpireDate];
        if (completion) {
            completion();
        }
    }];
}

- (ATHSocialAuthCredential *)_credentialFromToken:(FBSDKAccessToken *)token grantedPermissions:(NSArray *)grantedPermissions declinedPermissions:(NSArray *)declinedPermissions
{
    ATHSocialAuthCredential *credential = [ATHSocialAuthCredential new];
    credential.platform = ATHSocialPlatformFacebook;
    credential.token = token.tokenString;
    credential.estimatedExpireDate = token.expirationDate;
    credential.customInfo = @{
                              kSocialFBGrantedPermissionsKey: grantedPermissions ? : @[],
                              kSocialFBDeclinedPermissionsKey: declinedPermissions ? : @[],
                              kSocialFBAppIdKey: token.appID?:@"",
                              kSocialFBUserIdKey: token.userID?:@"",
                              kSocialFBTokenRefreshDateKey: token.refreshDate?:[NSDate date]
                              };
    return credential;
}

- (void)_getUserInfo
{
    if (NEED_FETCH_USERINFO) {
        [FBSDKProfile loadCurrentProfileWithCompletion:^(FBSDKProfile *profile, NSError *error) {
            if (error) {
                [LOGGER log:@"FacebookAuth load profile error %@",error];
                USERINFO_COMPLETE(nil, [NSError errorWithDomain:kATHSocialFacebookProfileError code:error.code userInfo:@{@"reason": @"Facebook load profile failed."}]);
                return ;
            }
            ATHSocialBaseUserInfo *info = [ATHSocialBaseUserInfo new];
            info.nickname = profile.name;
            info.avatarUrl =  [[profile imageURLForPictureMode:FBSDKProfilePictureModeNormal size:CGSizeMake(256, 256)] absoluteString];
            
            info.uid = profile.userID;
            info.gender = ATHSocialUserGenderUnknown;
            info.signature = @"";
            USERINFO_COMPLETE(info, nil);
        }];
    }
}

- (void)_checkPublishPermissionThen:(void(^)(BOOL granted))completion
{
    void (^checkPermission)(void) = ^{
        NSString *publishPermission = @"publish_pages";
        NSString *managePermission = @"manage_pages";
        if ([[FBSDKAccessToken currentAccessToken] hasGranted:publishPermission] && [[FBSDKAccessToken currentAccessToken] hasGranted:managePermission]) {
            completion(YES);
        }else {
            [[self fblogin] logInWithPublishPermissions:@[publishPermission,managePermission] fromViewController:self.vcGenerator() handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
                if (error || ![result.grantedPermissions containsObject: publishPermission] || ![result.grantedPermissions containsObject: managePermission]) {
                    [LOGGER log:@"Facebook Impl, publish permission not granted."];
                    completion(NO);
                }else {
                    ATHSocialAuthCredential *credential = [self _credentialFromToken:result.token grantedPermissions:[result.grantedPermissions allObjects] declinedPermissions:[result.declinedPermissions allObjects]];
                    
                    [ATHSocialCredentialStorage storeCredential:credential];
                    completion(YES);
                }
            }];
        }
    };
    ATHSocialAuthCredential *credential = nil;
    if (![FBSDKAccessToken currentAccessToken]) {
        credential = [ATHSocialCredentialStorage credentialForPlatform:ATHSocialPlatformFacebook];
    }
    if ([credential stillValid]) { //credential invalid，or there is already a accessToken, go straight to check.
        [LOGGER log:@"FacebookAuth using cached credential, expr date: %@",credential.estimatedExpireDate];
        AUTH_COMPLETE(credential, nil);
        [self _setupFacebookWithCredential:credential completion:checkPermission];
    }else {
        checkPermission();
    }
}

#pragma mark - FBSDKSharingDelegate
- (void)sharer:(id<FBSDKSharing>)sharer didCompleteWithResults:(NSDictionary *)results
{
    [LOGGER log:@"FacebookImpl share success with results: %@",results];
    SHARE_COMPLETE(YES, nil);
}

- (void)sharer:(id<FBSDKSharing>)sharer didFailWithError:(NSError *)error
{
    [LOGGER log:@"FacebookImpl share error: %@",error];
    
    if ([error.userInfo[FBSDKErrorArgumentNameKey] isEqualToString:@"shareContent"]) {
        NSString *errorDesc = error.userInfo[FBSDKErrorDeveloperMessageKey];
        if ([errorDesc containsString:@"Feed share dialogs support FBSDKShareLinkContent"]) { //有点搓，然而 fb 抛的 error 没有一个可以参照的 code
            NSError *installationError = [NSError errorWithDomain:kATHSocialFacebookShareError code:ATHSocialShareErrorCodeAppNotInstalled userInfo:nil];
            SHARE_COMPLETE(NO, installationError);
            return ;
        }
    }
    
    NSError *internalError = [NSError errorWithDomain:kATHSocialFacebookShareError code:ATHSocialShareErrorCodeSDKError userInfo:@{@"reason": @"Facebook internal error."}];
    SHARE_COMPLETE(NO, internalError);
    
}

- (void)sharerDidCancel:(id<FBSDKSharing>)sharer
{
    NSError *cancelError = [NSError errorWithDomain:kATHSocialFacebookShareError code:ATHSocialShareErrorCodeCancelled userInfo:nil];
    SHARE_COMPLETE(NO, cancelError);
}

#pragma mark - Getter

- (FBSDKApplicationDelegate *)fbapp
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [[FBSDKApplicationDelegate sharedInstance] application:self.application didFinishLaunchingWithOptions:self.launchOptions];
    });
    return [FBSDKApplicationDelegate sharedInstance];
}

- (FBSDKLoginManager *)fblogin
{
    if (!_fblogin) {
        _fblogin = [FBSDKLoginManager new];
        _fblogin.defaultAudience = FBSDKDefaultAudienceEveryone;
//        _fblogin.loginBehavior = FBSDKLoginBehaviorWeb;
    }
    return _fblogin;
}

@end
