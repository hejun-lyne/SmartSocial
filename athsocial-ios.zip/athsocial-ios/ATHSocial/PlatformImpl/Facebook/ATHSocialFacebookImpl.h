//
//  ATHSocialFacebookImpl.h
//  ATHSocial
//
//  Created by Gocy on 2018/6/7.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialBaseImpl.h"

//NS_ASSUME_NONNULL_BEGIN

@interface ATHSocialFacebookImpl : ATHSocialBaseImpl

@end

//NS_ASSUME_NONNULL_END
