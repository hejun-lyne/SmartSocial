//
//  ATHSocialShareInfo.m
//  ATHSocial
//
//  Created by Gocy on 2018/7/23.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import "ATHSocialShareInfo.h"

@implementation ATHSocialShareInfo

@synthesize title = _title;
@synthesize subTitle = _subTitle;
@synthesize content = _content;
@synthesize shareImages = _shareImages;

@synthesize url = _url;
@synthesize preferredImageFormat = _preferredImageFormat;

@end
