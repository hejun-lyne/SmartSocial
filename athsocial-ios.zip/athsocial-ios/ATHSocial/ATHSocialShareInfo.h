//
//  ATHSocialShareInfo.h
//  ATHSocial
//
//  Created by Gocy on 2018/7/23.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IATHShareInfo.h"

@interface ATHSocialShareInfo : NSObject <IATHShareInfo>

@end
