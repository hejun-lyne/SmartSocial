//
//  ATHSocialDemoUITests.m
//  ATHSocialDemoUITests
//
//  Created by Gocy on 2018/7/16.
//  Copyright © 2018 Gocy. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <WebKit/WKWebsiteDataStore.h>

@interface ATHSocialDemoUITests : XCTestCase

@end

@implementation ATHSocialDemoUITests

- (void)setUp {
    [super setUp];
    
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
    // In UI tests it is usually best to stop immediately when a failure occurs.
    self.continueAfterFailure = NO;
    // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
    XCUIApplication *app = [XCUIApplication new];
    
    // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    app.launchEnvironment = @{@"animationsEnable": @"NO"};
    [app launch];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}


- (void)testFacebookAuth
{
    XCUIApplication *app = [[XCUIApplication alloc] init];
    [app.buttons[@"remove all cache"] tap];
    
    NSString *alertString = [NSString stringWithUTF8String:"\u201cATHSocialDemo\u201d Wants to Use \u201cfacebook.com\u201d to Sign In"];
    
    XCTestExpectation *expect = [self expectationWithDescription:@"FB Auth Web"];

    id monitor = [self addUIInterruptionMonitorWithDescription:alertString handler:^BOOL(XCUIElement * _Nonnull interruptingElement) {
        XCUIElement *continueButton = interruptingElement.buttons[@"Continue"];
        if ([continueButton exists]) {
            [continueButton tap];
            sleep(2);
            [expect fulfill];
            return YES;
        }
        
        return NO;
    }];
    [app.buttons[@"Auth Facebook"] tap];
    [app tap];
    
    [self waitForExpectations:@[expect] timeout:10];
    
    [self removeUIInterruptionMonitor:monitor];
    
    
    if (app.webViews.textFields.count > 0 && app.webViews.secureTextFields.count > 0) {
        //first time login
        XCUIElement *accountField = [app.webViews.textFields elementBoundByIndex:0];
        [self _enterAccountForElement:accountField app:app];
        
        XCUIElement *pwdField = [app.webViews.secureTextFields elementBoundByIndex:0];
        [self _enterPassworkdForField:pwdField];
        
        XCUIElement *loginButton = app.webViews.buttons[@"登录"];
        if (![loginButton exists]) {
            loginButton = app.webViews.buttons[@"Log in"];
        }
        
        if ([loginButton exists]) {
            [loginButton tap];
        }
    
        sleep(5);
        
        XCUIElement *confirmButton = app.webViews.buttons[@"继续"];
        if (![confirmButton exists]) {
            confirmButton = app.webViews.buttons[@"Continue"];
        }
        
        if ([confirmButton exists]) {
            [confirmButton tap];
        }
        
        sleep(4);
        
    }else if (app.webViews.buttons.count > 0){
        
        [[app.webViews.buttons elementBoundByIndex:0] tap];
        
        sleep(4);
    }
    
    [self _validateTokenForApp:app];
    
}



- (void)testInstagram
{
    XCUIApplication *app = [[XCUIApplication alloc] init];
    [app.buttons[@"remove all cache"] tap];
    
    [app.buttons[@"Auth Instagram"] tap];
    
    sleep(6);
    if (app.webViews.textFields.count > 0 && app.webViews.secureTextFields.count > 0) {
        XCUIElement *accountField = [app.webViews.textFields elementBoundByIndex:0];
        [self _enterAccountForElement:accountField app:app];
        
        XCUIElement *pwdField = [app.webViews.secureTextFields elementBoundByIndex:0];
        [self _enterPassworkdForField:pwdField];
        
        XCUIElement *confirm = app.webViews.buttons[@"Log in"];
        [confirm tap];
        
        sleep(4);
        
        XCUIElement *saveInfo = app.webViews.buttons[@"Not Now"];
        if ([saveInfo exists]) {
            [saveInfo tap];
            sleep(4);
        }
        
        XCUIElement *authorize = app.webViews.buttons[@"Authorize"];
        if ([authorize exists]) {
            [authorize tap];
            sleep(4);
        }
        
    }
    
    [self _validateTokenForApp:app];
}

- (void)testVKAuth
{
    XCUIApplication *app = [[XCUIApplication alloc] init];
    [app.buttons[@"remove all cache"] tap];
    
    [app.buttons[@"Auth VK"] tap];
    
    sleep(8);
    if (app.webViews.textFields.count > 0 && app.webViews.secureTextFields.count > 0) {
        XCUIElement *accountField = [app.webViews.textFields elementBoundByIndex:0];
        [self _enterAccountForElement:accountField app:app];
        
        XCUIElement *pwdField = [app.webViews.secureTextFields elementBoundByIndex:0];
        [self _enterPassworkdForField:pwdField];
        
        XCUIElement *confirm = app.webViews.buttons[@"Log in"];
        [confirm tap];
        
        sleep(8);
        
        XCUIElement *authorize = app.webViews.staticTexts[@"Allow"];
        if ([authorize exists]) {
            [authorize tap];
            sleep(4);
        }
        
    }
    
    [self _validateTokenForApp:app];
}

- (void)testTwitchAuth
{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    [app.buttons[@"remove all cache"] tap];
    
    [app.buttons[@"Auth Twitch"] tap];
    
    sleep(8);
    
    
    if (app.webViews.textFields.count > 0 && app.webViews.secureTextFields.count > 0) {
        XCUIElement *accountField = [app.webViews.textFields elementBoundByIndex:0];
        [self _enterAccountForElement:accountField app:app];
        
        XCUIElement *pwdField = [app.webViews.secureTextFields elementBoundByIndex:0];
        [self _enterPassworkdForField:pwdField];
        
        XCUIElement *confirm = app.webViews.buttons[@"Log In"];
        [confirm tap];
        
        sleep(6);
        
        XCUIElement *authorizeButton = app.webViews.buttons[@"Authorize"];
        if ([authorizeButton exists]) {
            //first login
            [authorizeButton tap];
            sleep(5);
        }
    }
    
    [self _validateTokenForApp:app];
}

- (void)_validateTokenForApp:(XCUIApplication *)app
{
    sleep(1);
    
    XCUIElement *resLabel = [app.staticTexts elementMatchingType:XCUIElementTypeAny identifier:@"token_res_label"];
    
    XCTAssert(resLabel.label.length > 0);

}

- (void)_validateShareResultForApp:(XCUIApplication *)app
{
    sleep(1);
    
    XCUIElement *resLabel = [app.staticTexts elementMatchingType:XCUIElementTypeAny identifier:@"share_res_label"];
    
    XCTAssert([resLabel.label isEqualToString:@"True"]);
}

- (void)_removeWebViewCacheWithCompletion:(void(^)(void))completion
{
    // Do any additional setup after loading the view, typically from a nib.
    NSSet *websiteDataTypes
    = [NSSet setWithArray:@[
                            WKWebsiteDataTypeDiskCache,
                            WKWebsiteDataTypeOfflineWebApplicationCache,
                            WKWebsiteDataTypeMemoryCache,
                            WKWebsiteDataTypeLocalStorage,
                            WKWebsiteDataTypeCookies,
                            WKWebsiteDataTypeSessionStorage,
                            WKWebsiteDataTypeIndexedDBDatabases,
                            WKWebsiteDataTypeWebSQLDatabases,
                            //WKWebsiteDataTypeFetchCache, //(iOS 11.3, *)
                            //WKWebsiteDataTypeServiceWorkerRegistrations, //(iOS 11.3, *)
                            ]];
    //// All kinds of data
    //NSSet *websiteDataTypes = [WKWebsiteDataStore allWebsiteDataTypes];
    //// Date from
    NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
    //// Execute
    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes modifiedSince:dateFrom completionHandler:^{
        // Done
        
        completion();
    }];
    
}


#pragma mark - Share
//- (void)testFacebookShare
//{

//    XCUIApplication *app = [[XCUIApplication alloc] init];
//
//    [app.buttons[@"Share Facebook"] tap];
//
//    sleep(4);
    
    
//    if (app.webViews.secureTextFields.count > 0) {
//        //require login first
//        XCUIElement *accountField = [app.webViews.textFields elementBoundByIndex:0];
//        [self _enterAccountForElement:accountField app:app];
//
//        XCUIElement *pwdField = [app.webViews.secureTextFields elementBoundByIndex:0];
//        [self _enterPassworkdForField:pwdField];
//
//        XCUIElement *confirm = app.webViews.buttons[@"Log In"];
//        [confirm tap];
//
//        sleep(2);
//    }
//
//
//    app.webViews;
//}

- (void)testVKShare
{
    XCUIApplication *app = [[XCUIApplication alloc] init];
    
    [app.buttons[@"Share VK"] tap];
    
    sleep(7);
    
    if (app.webViews.secureTextFields.count > 0) {
        // requires login first
        XCUIElement *accountField = [app.webViews.textFields elementBoundByIndex:0];
        [self _enterAccountForElement:accountField app:app];
        
        XCUIElement *pwdField = [app.webViews.secureTextFields elementBoundByIndex:0];
        [self _enterPassworkdForField:pwdField];
        
        XCUIElement *confirm = app.webViews.buttons[@"Log in"];
        [confirm tap];
        
        sleep(6);
        
        XCUIElement *authorize = app.webViews.staticTexts[@"Allow"];
        if ([authorize exists]) {
            [authorize tap];
            sleep(3);
        }
    }
    
    [app.buttons[@"Done"] tap];
    
    sleep(3);
    
    [self _validateShareResultForApp:app];
}

- (void)_enterAccountForElement:(XCUIElement *)accountField app:(XCUIApplication *)app
{
    NSString *account = @"gocytest@163.com";
    [accountField tap];
    NSString *content = accountField.value;
    NSMutableString *del = [NSMutableString new];
    for (NSUInteger i = 0; i < content.length; ++i) {
        [del appendString:XCUIKeyboardKeyDelete];
    }
    
    [accountField typeText:del];
    
    [accountField typeText:account];
}

- (void)_enterPassworkdForField:(XCUIElement *)pwdField
{
    NSString *pwd = @"haha1234";
    [pwdField tap];
    [pwdField typeText:pwd];
}

@end
