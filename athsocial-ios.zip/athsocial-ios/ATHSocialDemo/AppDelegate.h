//
//  AppDelegate.h
//  ATHShareDemo
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

