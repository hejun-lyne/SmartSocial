//
//  DemoShareInfo.m
//  ATHShareDemo
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#import "DemoShareInfo.h"

@implementation DemoShareInfo

@synthesize title = _title;
@synthesize subTitle = _subTitle;
@synthesize content = _content;
@synthesize shareImages = _shareImages;

@synthesize url = _url;
@synthesize preferredImageFormat = _preferredImageFormat;

@end
