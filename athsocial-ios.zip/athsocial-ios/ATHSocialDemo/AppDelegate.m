//
//  AppDelegate.m
//  ATHShareDemo
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#import "AppDelegate.h"
#import "NSDictionary+SocialParameters.h"
#import "ATHSocial.h"

#define kSinaWeiboSDKAppKey @"1727072384"
#define kSinaWeiboSDKAppSecret @"7ca079a7a4c229402193c8fd0c54f304"
#define KWXSDKAppKey @"wxe99623d9884aa324" //@"wxfc848d18e8459ceb"
#define KWXSDKAppSecret @"d4624c36b6795d1d99dcf0547af5443d"
#define kGoogleClientId @"730147526325-ugo7uqj4re4cjj1b67s2ki2ujua3c8m1.apps.googleusercontent.com"

@interface AppDelegate () <IATHSocialLoggerDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    NSMutableDictionary *config = [NSMutableDictionary new];
    
    [config athsocial_setupGoogleClientId:@"730147526325-ugo7uqj4re4cjj1b67s2ki2ujua3c8m1.apps.googleusercontent.com"];
    
    [config athsocial_setupTwitterConsumerKey:@"ZH7uj2WwSAWWNlLOtqS2Ov2kB" consumerSecret:@"p7i4M71IUgUDjMuNw38BjKwwWLqaLdzCW541B41jybsGTGGsXj" redirectUrl:@"https://yy.com/yymf/twitter/idontexist"];
    
    [config athsocial_setupWeiboAppKey:kSinaWeiboSDKAppKey
                                 secret:kSinaWeiboSDKAppSecret
                            redirectUrl:@"http://"
                             authPolicy:ATHAuthPolicyAll];
    
    [config athsocial_setupInstagramClientId:@"79eaac8d756b456b8bc409f446272b68" redirectUrl:@"https://yy.com/yymf/twitter/idontexist"];
    
    [config athsocial_setupVKAppId:@"6604054"];
    
    [config athsocial_setupTwitchClientId:@"ypkkvgy5bzh9tmv4no7kscf7i1d16c" secret:@"9s31gr7ooi4pqucj4xjd58fby425uz" redirectUrl:@"https://yy.com/yymf/twitter/idontexist"];
    
    [ATH_SERVICE(IATHSocial) setLoggerDelegate:self];
    
    [ATH_SERVICE(IATHSocial) application:application didFinishLaunchingWithOptions:launchOptions];
    
    [ATH_SERVICE(IATHSocial)
     registerSocialPlatforms:
     ATHSocialPlatformSinaWeibo |
     ATHSocialPlatformGoogle |
     ATHSocialPlatformFacebook |
     ATHSocialPlatformTwitter |
     ATHSocialPlatformInstagram |
     ATHSocialPlatformVK |
     ATHSocialPlatformTwitch
     withConfiguration:config];
    return YES;
}



- (void)log:(NSString *)format, ...
{
    va_list args;
    va_start(args, format);
    NSLog(@"%@",[[NSString alloc] initWithFormat:format arguments:args]);
    va_end(args);
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

//- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray * _Nullable))restorationHandler{
//    return YES;
//}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    return [ATH_SERVICE(IATHSocial) application:application handleOpenURL:url sourceApplication:nil annotation:nil];
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    return [ATH_SERVICE(IATHSocial) application:app openURL:url options:options];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    return [ATH_SERVICE(IATHSocial) application:application handleOpenURL:url sourceApplication:sourceApplication annotation:annotation];
}
@end
