//
//  DemoShareInfo.h
//  ATHShareDemo
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IATHShareInfo.h"

@interface DemoShareInfo : NSObject <IATHShareInfo>

@end
