//
//  ViewController.m
//  ATHShareDemo
//
//  Created by Gocy on 2018/6/5.
//  Copyright © 2018年 Gocy. All rights reserved.
//

#import "ViewController.h"
#import "ATHContext.h"
#import "DemoShareInfo.h"
#import "UIImageView+WebCache.h"
//#import <FBSDKLoginLoginKit/FBSDKLoginButton.h>
//#import "FBSDKLoginButton.h"
//#import <FBSDKShareKit/FBSDKShareKit.h>
#import <WebKit/WKWebsiteDataStore.h>
#import "ATHSocial.h"

#define DIRECT_GET_USERINFO 0

@interface ViewController () <IATHSocialUIDelegate>
@property (weak, nonatomic) IBOutlet UILabel *nickLabel;
@property (weak, nonatomic) IBOutlet UIImageView *avatarImageView;
@property (nonatomic, strong) IBOutlet UILabel *tokenResultLabel;
@property (weak, nonatomic) IBOutlet UILabel *shareResultLabel;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [ATH_SERVICE(IATHSocial) setUiDelegate:self];
    
    
//    FBSDKLoginButton *loginButton = [[FBSDKLoginButton alloc] init];
//    // Optional: Place the button in the center of your view.
//    loginButton.center = CGPointMake(self.view.center.x,self.view.center.y + self.view.bounds.size.height * 0.85 / 2);
//    loginButton.readPermissions = @[@"public_profile"];
//    [self.view addSubview:loginButton];
    
    
//    FBSDKShareButton *shareButton = [[FBSDKShareButton alloc] init];
//    // Optional: Place the button in the center of your view.
//    shareButton.center = CGPointMake(self.view.center.x,self.view.center.y + self.view.bounds.size.height * 0.85 / 2);
//    FBSDKShareMediaContent *content = [FBSDKShareMediaContent new];
//    content.media = @[
//                      [FBSDKSharePhoto photoWithImage:[UIImage imageNamed:@"racing"] userGenerated:YES]
//                      ];
//    [self.view addSubview:shareButton];
//    shareButton.shareContent = content;
    NSSet *websiteDataTypes
    = [NSSet setWithArray:@[
                            WKWebsiteDataTypeDiskCache,
                            WKWebsiteDataTypeOfflineWebApplicationCache,
                            WKWebsiteDataTypeMemoryCache,
                            WKWebsiteDataTypeLocalStorage,
                            WKWebsiteDataTypeCookies,
                            WKWebsiteDataTypeSessionStorage,
                            WKWebsiteDataTypeIndexedDBDatabases,
                            WKWebsiteDataTypeWebSQLDatabases,
                            //WKWebsiteDataTypeFetchCache, //(iOS 11.3, *)
                            //WKWebsiteDataTypeServiceWorkerRegistrations, //(iOS 11.3, *)
                            ]];
    //// All kinds of data
    //NSSet *websiteDataTypes = [WKWebsiteDataStore allWebsiteDataTypes];
    //// Date from
    NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
    //// Execute
    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes modifiedSince:dateFrom completionHandler:^{
        // Done
        NSLog(@"Good to go.");
    }];
    
    self.tokenResultLabel.accessibilityLabel = @"token_res_label";
    self.shareResultLabel.accessibilityLabel = @"share_res_label";
}

- (IBAction)authWeibo:(id)sender
{

#if DIRECT_GET_USERINFO
    [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformSinaWeibo completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
        if (!error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.nickLabel.text = userInfo.nickname;
                [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
            });
        }
    }];
#else
    [ATH_SERVICE(IATHSocial) requestAuthForPlatform:ATHSocialPlatformSinaWeibo extendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
        if (credential) {
            [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformSinaWeibo completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
                if (!error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.nickLabel.text = userInfo.nickname;
                        [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
                    });
                }
            }];
            [self setTokenResult:credential.token];
        }
    }];
#endif
}
- (IBAction)authGoogle:(id)sender
{

#if DIRECT_GET_USERINFO
    [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformGoogle completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
        if (!error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.nickLabel.text = userInfo.nickname;
                [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
            });
        }
    }];
#else
    [ATH_SERVICE(IATHSocial) requestAuthForPlatform:ATHSocialPlatformGoogle extendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
        if (credential) {
            [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformGoogle completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
                if (!error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.nickLabel.text = userInfo.nickname;
                        [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
                    });
                }
            }];
            
            [self setTokenResult:credential.token];
        }
    }];
#endif
}
- (IBAction)authFacebook:(id)sender {

#if DIRECT_GET_USERINFO
    [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformFacebook completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
        if (!error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.nickLabel.text = userInfo.nickname;
                [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
            });
        }
    }];
#else
    [ATH_SERVICE(IATHSocial) requestAuthForPlatform:ATHSocialPlatformFacebook extendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
        if (credential) {
            [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformFacebook completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
                if (!error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.nickLabel.text = userInfo.nickname;
                        [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
                    });
                }
            }];
            [self setTokenResult:credential.token];
        }
    }];
#endif
}
- (IBAction)authInstagram:(id)sender {
    
#if DIRECT_GET_USERINFO
    [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformInstagram completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
        if (!error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.nickLabel.text = userInfo.nickname;
                [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
            });
        }
    }];
#else
    [ATH_SERVICE(IATHSocial) requestAuthForPlatform:ATHSocialPlatformInstagram extendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
        if (credential) {
            [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformInstagram completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
                if (!error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.nickLabel.text = userInfo.nickname;
                        [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
                    });
                }
            }];
            [self setTokenResult:credential.token];
        }
    }];
#endif
}
- (IBAction)authTwitter:(id)sender {

#if DIRECT_GET_USERINFO
    [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformTwitter completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
        if (!error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.nickLabel.text = userInfo.nickname;
                [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
            });
        }
    }];
#else
    [ATH_SERVICE(IATHSocial) requestAuthForPlatform:ATHSocialPlatformTwitter extendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
        if (credential) {
            [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformTwitter completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
                if (!error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.nickLabel.text = userInfo.nickname;
                        [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
                    });
                }
            }];
            [self setTokenResult:credential.token];
        }
    }];
#endif
}

- (IBAction)authVK:(id)sender {

#if DIRECT_GET_USERINFO
    [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformVK completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
        if (!error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.nickLabel.text = userInfo.nickname;
                [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
            });
        }
    }];
#else
    [ATH_SERVICE(IATHSocial) requestAuthForPlatform:ATHSocialPlatformVK extendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
        if (credential) {
            [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformVK completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
                if (!error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.nickLabel.text = userInfo.nickname;
                        [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
                    });
                }
            }];
            [self setTokenResult:credential.token];
        }
    }];
#endif
}
- (IBAction)authTwitch:(id)sender {
#if DIRECT_GET_USERINFO
    
    [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformTwitch completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
        if (!error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.nickLabel.text = userInfo.nickname;
                [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
            });
        }
    }];
#else
    [ATH_SERVICE(IATHSocial) requestAuthForPlatform:ATHSocialPlatformTwitch extendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
        if (!error) {
            [ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformTwitch completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
                if (!error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        self.nickLabel.text = userInfo.nickname;
                        [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.avatarUrl] placeholderImage:nil];
                    });
                }
            }];
            [self setTokenResult:credential.token];
        }
    }];
#endif
}

- (IBAction)removeAuthCache:(id)sender {
    [ATH_SERVICE(IATHSocial) cleanAuthCacheForPlatforms:ATHSocialPlatformAll];
}

#define DEMO_INFO [self demoShareInfo]

- (IBAction)shareWeibo:(id)sender
{
    [ATH_SERVICE(IATHSocial) shareToChannel:ATHShareChannelSinaWeibo info:DEMO_INFO completion:^(BOOL success, NSError *error) {
        [self setShareResult:success ? @"True" : @"False"];
    }];
}
- (IBAction)shareInstagram:(id)sender {
    
    [ATH_SERVICE(IATHSocial) shareToChannel:ATHShareChannelInstagram info:DEMO_INFO completion:^(BOOL success, NSError *error) {
        [self setShareResult:success ? @"True" : @"False"];
    }];
}

- (IBAction)sharewechatFriend:(id)sender
{
    [ATH_SERVICE(IATHSocial) shareToChannel:ATHShareChannelWechatFriend info:DEMO_INFO completion:^(BOOL success, NSError *error) {
        
    }];
}
- (IBAction)shareWechatMoments:(id)sender
{
    [ATH_SERVICE(IATHSocial) shareToChannel:ATHShareChannelWechatMoments info:DEMO_INFO completion:^(BOOL success, NSError *error) {
        
    }];
}
- (IBAction)shareFacebook:(id)sender {
    
    DemoShareInfo *info = DEMO_INFO;
    info.shareImages = nil; 
    [ATH_SERVICE(IATHSocial) shareToChannel:ATHShareChannelFacebook info: info completion:^(BOOL success, NSError *error) {
        [self setShareResult:success ? @"True" : @"False"];
    }];
}
- (IBAction)shareTwitter:(id)sender {
    
    DemoShareInfo *info = DEMO_INFO;
    info.shareImages = @[[UIImage imageNamed:@"car"],@"https://criticsroundup.com/wp-content/uploads/2013/04/the-dark-knight-rises-still-526x295.jpg",[UIImage imageNamed:@"racing"]];
    [ATH_SERVICE(IATHSocial) shareToChannel:ATHShareChannelTwitter info: info completion:^(BOOL success, NSError *error) {
        [self setShareResult:success ? @"True" : @"False"];
    }];
}
- (IBAction)shareVK:(id)sender {
    
    [ATH_SERVICE(IATHSocial) shareToChannel:ATHShareChannelVK info:DEMO_INFO completion:^(BOOL success, NSError *error) {
        [self setShareResult:success ? @"True" : @"False"];
    }];
}

- (DemoShareInfo *)demoShareInfo
{
    
    DemoShareInfo *info = [DemoShareInfo new];
    info.title = @"Share Title";
    info.subTitle = @"share subtitle";
    info.content = @"content goes here.";
    info.url = @"https://yy.com";
    info.shareImages = @[@"https://criticsroundup.com/wp-content/uploads/2013/04/the-dark-knight-rises-still-526x295.jpg",[UIImage imageNamed:@"car"],[UIImage imageNamed:@"racing"]];
    
    return info;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Delegates

- (UIViewController *)viewControllerForPresent
{
    return self;
}

- (UIViewController *)viewControllerForPush
{
    return self;
}


#pragma mark - Test Purpose
- (void)setTokenResult:(NSString *)result
{
    dispatch_async(dispatch_get_main_queue(), ^{
        self.tokenResultLabel.text = result;
        [self.tokenResultLabel sizeToFit];
    });
    
}

- (void)setShareResult:(NSString *)result
{
    dispatch_async(dispatch_get_main_queue(), ^{
        self.shareResultLabel.text = result;
        [self.shareResultLabel sizeToFit];
    });
}
@end
