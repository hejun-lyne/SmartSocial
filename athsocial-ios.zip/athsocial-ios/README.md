# ATHSocial iOS 社会化组件


## 特别注意
Service 内部是有机制缓存 token/刷新 token 的，每当调用 `requestAuthForPlatform:` 时，会优先返回缓存的 token，并调用对应平台接口刷新 token 以供下次使用，但有极个别特殊的平台，token 没有有效期（如 Twitter），所以自然也没有刷新逻辑。

另外，由于不是每次都直接请求 token，有可能出现一下两种情况：
1. 缓存 token 过期

    这种情况，Service 内部会自动转为重新请求 token，一般表现为调起平台授权界面。对应用层来说一般不需要特殊处理。

2. 缓存 token 未过期，但用户在三方平台上手动撤销授权，或因其他原因 token 失效
    
    这种情况，Service 会返回缓存的 token，但该 token 其实已经失效了，会导致业务请求失败，建议业务层与后端对接好 invalid token 的情况，并在出现该种情况时，主动调用 Service 的 `cleanAuthCacheForPlatforms:` 清除对应平台的缓存，保证下一次调用 `requestAuthForPlatform:` 时，Service 会走授权界面逻辑。


## 平台支持

| Platform | Authentification (App & Web) | Share Text & Url (App & Web) | Share Images (App & Web) | Share Video 
| :------: | :--------------: | :--------------: | :---------: | :---------: 
|Sina Weibo| ✓ | ✓ | ✓ (1 image in web) | 
|Wechat||||
|QQ||||
|Facebook|✓|✓(Web First)|✓ (App Only)
|Twitter|✓(Web Only)|✓(Web Only)|✓(Web Only)
|Instagram|✓(Web Only)||✓(1 image only)
|VKontakte(VK)|✓(Web Only)|✓(Web Only)|✓(Web Only)
|Twitch|✓(Web Only)|||


## 使用说明
### 接入
Service 使用 Cocoapods 方式引入，其中默认引入全平台支持。
```ruby
pod 'athsocial', 'version'
```
若只需要一部分平台，支持 subspec 形式引入：
```ruby
pod 'athsocial', 'version', :subspec => ['Google', 'Facebook', ...]
```

### 初始化
首先，根据各分享平台的要求，申请完各种 Id，配置好 URLType 和 plist 白名单。随后初始化 Service：
```objc
#import <athcontext/NSDictionary+SocialParameters.h>

NSMutableDictionary *config = [NSMutableDictionary new];

//利用 category 方法，填入平台参数
[config athsocial_setupGoogleClientId:GOOGLE_CLIENT_ID];
[config athsocial_setupTwitterConsumerKey:TWITTER_CONSUMER_KEY consumerSecret:TWITTER_CONSUMER_SECRET redirectUrl:TWITTER_REDIRECT_URL];
//[config athsocial_setXXX];

//此句非必须调用，但建议调用。
[ATH_SERVICE(IATHSocial) application:application didFinishLaunchingWithOptions:launchOptions];
    
//初始化 service
[ATH_SERVICE(IATHSocial)
     registerSocialPlatforms:
     ATHSocialPlatformGoogle |
     ATHSocialPlatformFacebook |
     ATHSocialPlatformTwitter | .....
     withConfiguration:config];
```

其中，除了
```objc
[ATH_SERVICE(IATHSocial) application:application didFinishLaunchingWithOptions:launchOptions];
```
建议在启动时调用外，另外的初始化方法均可自行决定初始化时机，当然，必须在实际使用 service 之前调用。更多关于三方平台的账户申请和参数配置，可以看 [这里](./docsupport/platform_register.md)

### 授权、用户信息和分享
调用授权，只需要传入必要参数：
```objc
[ATH_SERVICE(IATHSocial) requestAuthForPlatform:ATHSocialPlatformGoogle extendInfo:nil authCompletion:^(ATHSocialAuthCredential *credential, NSError *error) {
    //use credential.token or anything else.
}];
```
Service 内部会自动对平台的 token 进行缓存和更新管理，业务层一般不需要关心其中的逻辑。由于平台之间存在差异性，因此 auth 和 userInfo 分为两个回调，若授权场景不需要知道 userInfo，可以传入 nil，这样 Service 内部就可以节省用户信息的请求了。目前，`extendInfo` 参数为保留字段，穿空即可。

获取三方用户信息，只需传入必要参数：
```objc
[ATH_SERVICE(IATHSocial) requestUserInfoForPlatform:ATHSocialPlatformSinaWeibo completion:^(ATHSocialBaseUserInfo *userInfo, NSError *error) {
    if (!error) {
        //do stuff with user info
    }
}];
```

调用分享，需要构造 `IATHShareInfo` 协议对象：
```objc
//somewhere implement this protocol
@interface DemoShareInfo : NSObject <IATHShareInfo>
@end

//somewhere trigger share action
DemoShareInfo *info = [DemoShareInfo new];
info.title = @"Share Title";
info.subTitle = @"share subtitle";
info.content = @"content goes here.";
info.url = @"https://yy.com";
info.shareImages =
 @[@"https://criticsroundup.com/wp-content/uploads/2013/04/the-dark-knight-rises-still-526x295.jpg",
    [UIImage imageNamed:@"car"],
    [UIImage imageNamed:@"racing"]
 ];

[ATH_SERVICE(IATHSocial) shareToChannel:ATHShareChannelTwitter info: info completion:^(BOOL success, NSError *error) {
    // do your stuff
}];
```
分享的图片数组支持传入 `NSString` 或是 `UIImage` 类型，Service 内部将自动完成下载、上传、分享的流程，由于涉及网络IO，建议此处给予用户相应提示或 Loading 界面，并在回调中进行 dismiss。

以上获取用户信息以及分享的操作，均需要用户进行授权。因此若业务方在调用授权之前，先调用了这两个接口，Service 内部将会先走授权流程。


## 版本记录

### 0.0.1-dev
首版本，实现基础接口并接入 `Sina Weibo`, `Facebook`, `Twitter`, `Instagram`, `VKontakte`

### 0.0.4-dev
接入 `Twitch` 授权，以及 Bug 修复。

## 其他说明
